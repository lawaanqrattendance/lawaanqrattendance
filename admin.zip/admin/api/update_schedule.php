<?php
// Allow from any origin
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Include necessary files
require_once '../../includes/config.php';
require_once '../../config/database.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';

// Check if user is logged in and has appropriate role
if (!isLoggedIn() || (getUserRole() !== 'admin' && getUserRole() !== 'teacher')) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit();
}

try {
    $schedule_id = cleanInput($_POST['schedule_id']);
    $userRole = getUserRole();
    
    // First verify the schedule exists and get its details
    $check_stmt = $conn->prepare("SELECT schedule_id, teacher_id FROM schedules WHERE schedule_id = ?");
    $check_stmt->bind_param("i", $schedule_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Schedule not found');
    }
    
    $schedule = $result->fetch_assoc();
    
    // For teachers, verify ownership
    if ($userRole === 'teacher') {
        // Get teacher's ID from session or users table
        if (!isset($_SESSION['teacher_id'])) {
            $teacher_stmt = $conn->prepare("SELECT reference_id FROM users WHERE user_id = ? AND role = 'teacher'");
            $teacher_stmt->bind_param("i", $_SESSION['user_id']);
            $teacher_stmt->execute();
            $teacher_result = $teacher_stmt->get_result();
            $teacher = $teacher_result->fetch_assoc();
            
            if (!$teacher) {
                throw new Exception('Teacher ID not found');
            }
            $_SESSION['teacher_id'] = $teacher['reference_id'];
        }
        
        if ($schedule['teacher_id'] != $_SESSION['teacher_id']) {
            throw new Exception('Unauthorized to modify this schedule');
        }
    }
    
    // Get the update data
    $day_of_week = cleanInput($_POST['day_of_week']);
    $start_time = cleanInput($_POST['start_time']);
    $end_time = cleanInput($_POST['end_time']);
    
    // Validate times
    if (strtotime($end_time) <= strtotime($start_time)) {
        throw new Exception('End time must be after start time');
    }
    
    // Check for schedule conflicts
    $conflict_check = $conn->prepare("
        SELECT COUNT(*) as conflict_count 
        FROM schedules 
        WHERE teacher_id = ? 
        AND day_of_week = ? 
        AND schedule_id != ?
        AND school_year = (
            SELECT school_year FROM schedules WHERE schedule_id = ?
        )
        AND (
            (start_time < ? AND end_time > ?) OR
            (start_time < ? AND end_time > ?) OR
            (start_time >= ? AND end_time <= ?)
        )
    ");
    
    $conflict_check->bind_param("isiissssss", 
        $schedule['teacher_id'],
        $day_of_week,
        $schedule_id,
        $schedule_id,
        $end_time,
        $start_time,
        $end_time,
        $start_time,
        $start_time,
        $end_time
    );
    
    $conflict_check->execute();
    $conflict_result = $conflict_check->get_result();
    $conflict_row = $conflict_result->fetch_assoc();
    
    if ($conflict_row['conflict_count'] > 0) {
        throw new Exception('Schedule conflict detected for this time slot');
    }

    // Update the schedule
    $stmt = $conn->prepare("UPDATE schedules SET day_of_week = ?, start_time = ?, end_time = ? WHERE schedule_id = ?");
    $stmt->bind_param("sssi", $day_of_week, $start_time, $end_time, $schedule_id);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Schedule updated successfully'
        ]);
    } else {
        throw new Exception('Database error: ' . $conn->error);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?> 