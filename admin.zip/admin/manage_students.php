<?php
include '../includes/header.php';
requireLogin();

if (getUserRole() !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Add after your includes
require '../vendor/autoload.php'; // For PHPMailer
require_once '../config/email_config.php'; // For email settings

function sendVerificationEmail($to, $code, $username, $temp_password) {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom(SMTP_USERNAME, SMTP_FROM_NAME);
        $mail->addAddress($to);

        $mail->isHTML(true);
        $mail->Subject = 'Welcome to Attendance System - Account Details';
        $mail->Body = "
            <html>
            <body style='font-family: Arial, sans-serif;'>
                <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
                    <h2>Welcome to the Attendance System</h2>
                    <p>Your account has been created with the following details:</p>
                    <p><strong>Username:</strong> {$username}</p>
                    <p><strong>Temporary Password:</strong> {$temp_password}</p>
                    <p><strong>Verification Code:</strong> {$code}</p>
                    <p>Please login and verify your email using the verification code above.</p>
                    <p>The verification code will expire in 1 hour.</p>
                </div>
            </body>
            </html>";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email Error: {$mail->ErrorInfo}");
        return false;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $student_id = cleanInput($_POST['student_id']);
                $firstname = cleanInput($_POST['firstname']);
                $lastname = cleanInput($_POST['lastname']);
                $middlename = cleanInput($_POST['middlename']);
                $email = cleanInput($_POST['email']);
                $section_id = cleanInput($_POST['section_id']);
                
                // Start transaction
                $conn->begin_transaction();
                
                try {
                    // Get grade level from section
                    $stmt = $conn->prepare("SELECT grade_level FROM sections WHERE section_id = ?");
                    $stmt->bind_param("i", $section_id);
                    $stmt->execute();
                    $grade_level = $stmt->get_result()->fetch_assoc()['grade_level'];

                    // Insert into students table
                    $stmt = $conn->prepare("INSERT INTO students (student_id, firstname, lastname, middlename, email, grade_level, section_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssssii", $student_id, $firstname, $lastname, $middlename, $email, $grade_level, $section_id);
                    
                    if ($stmt->execute()) {
                        // Create username in format firstname.lastname
                        $username = strtolower($firstname . '.' . $lastname);
                        
                        // Check if username exists and append number if needed
                        $count = 1;
                        $original_username = $username;
                        while (true) {
                            $check = $conn->prepare("SELECT username FROM users WHERE username = ?");
                            $check->bind_param("s", $username);
                            $check->execute();
                            if ($check->get_result()->num_rows === 0) {
                                break;
                            }
                            $username = $original_username . $count;
                            $count++;
                        }
                        
                        // Generate verification code and temporary password
                        $verification_code = sprintf("%06d", mt_rand(1, 999999));
                        $temp_password = bin2hex(random_bytes(4)); // 8 characters
                        $hashed_password = password_hash($temp_password, PASSWORD_DEFAULT);
                        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

                        // Create user account
                        $stmt = $conn->prepare("INSERT INTO users (username, password, role, reference_id, verification_code, code_expiry, email_verified) VALUES (?, ?, 'student', ?, ?, ?, 0)");
                        $stmt->bind_param("sssss", $username, $hashed_password, $student_id, $verification_code, $expiry);
                        
                        if ($stmt->execute()) {
                            // Send welcome email
                            if (sendVerificationEmail($email, $verification_code, $username, $temp_password)) {
                                $conn->commit();
                                $_SESSION['success_message'] = "Student added successfully! Account details sent to: " . $email;
                            } else {
                                throw new Exception("Failed to send welcome email");
                            }
                        }
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                    $_SESSION['error_message'] = "Error adding student: " . $e->getMessage();
                }

                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
                
            // ... other cases ...
        }
    }
}

// At the top of the page, after session start
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// Get all students
$query = "SELECT s.*, sec.section_name 
          FROM students s 
          LEFT JOIN sections sec ON s.section_id = sec.section_id 
          ORDER BY s.lastname, s.firstname";
$students = $conn->query($query);

// Get sections for dropdown
$sections = $conn->query("SELECT * FROM sections ORDER BY grade_level, section_name");
?>

<div class="row mb-4">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <h2>Manage Students</h2>
        <div class="d-flex gap-2">
            <!-- Search Input -->
            <div class="input-group" style="width: 300px;">
                <input type="text" id="searchInput" class="form-control" placeholder="Search students...">
                <button class="btn btn-outline-secondary" type="button" id="clearSearch">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <!-- Add Student Button -->
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                Add New Student
            </button>
        </div>
    </div>
</div>

<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<!-- Students Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive" style="overflow-y: scroll; max-height: 700px;">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Grade Level</th>
                        <th>Section</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($student = $students->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $student['student_id']; ?></td>
                            <td><?php echo $student['lastname'] . ', ' . $student['firstname'] . ' ' . $student['middlename']; ?></td>
                            <td>
                                <?php echo $student['email']; ?>
                                <?php
                                    // Get verification status from users table
                                    $stmt = $conn->prepare("SELECT email_verified FROM users WHERE reference_id = ? AND role = 'student'");
                                    $stmt->bind_param("s", $student['student_id']);
                                    $stmt->execute();
                                    $result = $stmt->get_result();
                                    $user = $result->fetch_assoc();
                                    if ($user && $user['email_verified']): ?>
                                        <span class="badge bg-success">Verified</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php endif; ?>
                            </td>
                            <td><?php echo $student['grade_level']; ?></td>
                            <td><?php echo $student['section_name']; ?></td>
                            <td>
                                <button type="button" 
                                        class="btn btn-primary btn-sm edit-student"
                                        data-id="<?php echo $student['student_id']; ?>"
                                        data-firstname="<?php echo $student['firstname']; ?>"
                                        data-lastname="<?php echo $student['lastname']; ?>"
                                        data-middlename="<?php echo $student['middlename']; ?>"
                                        data-email="<?php echo $student['email']; ?>"
                                        data-grade="<?php echo $student['grade_level']; ?>"
                                        data-section="<?php echo $student['section_id']; ?>">
                                    Edit
                                </button>
                                <button type="button" 
                                        class="btn btn-danger btn-sm delete-student"
                                        data-id="<?php echo $student['student_id']; ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Student Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label class="form-label">Student ID</label>
                        <div class="input-group">
                            <input type="text" class="form-control" name="student_id" id="studentId" required>
                            <span class="input-group-text" id="idAvailabilityIndicator">
                                <i class="fas fa-spinner fa-spin" style="display: none;"></i>
                            </span>
                        </div>
                        <small class="text-muted" id="idAvailabilityMessage"></small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">First Name</label>
                        <input type="text" class="form-control" name="firstname" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Last Name</label>
                        <input type="text" class="form-control" name="lastname" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Middle Name</label>
                        <input type="text" class="form-control" name="middlename">
                    </div>

                    <!-- New Email Field -->
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" class="form-control" name="email" required>
                        <small class="text-muted">Student will receive verification code at this email</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Section</label>
                        <select class="form-select" name="section_id" required>
                            <option value="">Select Section</option>
                            <?php 
                            // Reset sections result pointer
                            $sections->data_seek(0);
                            $current_grade = null;
                            
                            while ($section = $sections->fetch_assoc()):
                                if ($current_grade !== $section['grade_level']):
                                    if ($current_grade !== null) echo '</optgroup>';
                                    $current_grade = $section['grade_level'];
                                    echo "<optgroup label='Grade {$section['grade_level']}'>";
                                endif;
                            ?>
                                <option value="<?php echo $section['section_id']; ?>">
                                    <?php echo $section['section_name']; ?>
                                </option>
                            <?php 
                            endwhile;
                            if ($current_grade !== null) echo '</optgroup>';
                            ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Student</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Student Modal -->
<div class="modal fade" id="editStudentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editStudentForm">
                <div class="modal-body">
                    <input type="hidden" name="student_id" id="edit_student_id">
                    
                    <div class="mb-3">
                        <label class="form-label">First Name</label>
                        <input type="text" class="form-control" name="firstname" id="edit_firstname" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Last Name</label>
                        <input type="text" class="form-control" name="lastname" id="edit_lastname" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Middle Name</label>
                        <input type="text" class="form-control" name="middlename" id="edit_middlename">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="edit_email" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Section</label>
                        <select class="form-select" name="section_id" id="edit_section_id" required>
                            <option value="">Select Section</option>
                            <?php 
                            // Reset sections result pointer
                            $sections->data_seek(0);
                            $current_grade = null;
                            
                            while ($section = $sections->fetch_assoc()):
                                if ($current_grade !== $section['grade_level']):
                                    if ($current_grade !== null) echo '</optgroup>';
                                    $current_grade = $section['grade_level'];
                                    echo "<optgroup label='Grade {$section['grade_level']}'>";
                                endif;
                            ?>
                                <option value="<?php echo $section['section_id']; ?>">
                                    <?php echo $section['section_name']; ?>
                                </option>
                            <?php 
                            endwhile;
                            if ($current_grade !== null) echo '</optgroup>';
                            ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
const BASE_URL = '<?php echo BASE_URL; ?>';
</script>

<script>
$(document).ready(function() {
    // Function to show alerts
    function showAlert(message, type = 'success') {
        const alert = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">')
            .text(message)
            .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
        
        $('.row:first').after(alert);
        
        // Auto dismiss after 3 seconds
        setTimeout(() => {
            alert.alert('close');
        }, 3000);
    }

    // Edit Student
    $('.edit-student').click(function() {
        const button = $(this);
        const id = button.data('id');
        const firstname = button.data('firstname');
        const lastname = button.data('lastname');
        const middlename = button.data('middlename');
        const email = button.data('email');
        const grade = button.data('grade');
        const section = button.data('section');
        
        $('#edit_student_id').val(id);
        $('#edit_firstname').val(firstname);
        $('#edit_lastname').val(lastname);
        $('#edit_middlename').val(middlename);
        $('#edit_email').val(email);
        $('#edit_grade_level').val(grade);
        $('#edit_section_id').val(section);
        
        $('#editStudentModal').modal('show');
    });
    
    $('#editStudentForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        
        $.ajax({
            url: BASE_URL + '/admin/api/update_student.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                $('#editStudentModal').modal('hide');
                if (response.success) {
                    showAlert('Student updated successfully!');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    showAlert(response.error || 'Failed to update student', 'danger');
                }
            },
            error: function(xhr) {
                $('#editStudentModal').modal('hide');
                const errorMsg = xhr.responseJSON?.error || 'Failed to update student';
                showAlert(errorMsg, 'danger');
            }
        });
    });
    
    // Delete Student
    $('.delete-student').click(function() {
        if (confirm('Are you sure you want to delete this student? This will also delete their user account and all related records.')) {
            const button = $(this);
            const id = button.data('id');
            
            // Disable button while processing
            button.prop('disabled', true);
            
            $.ajax({
                url: BASE_URL + '/admin/api/delete_student.php',
                method: 'POST',
                data: { student_id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showAlert('Student deleted successfully!');
                        button.closest('tr').fadeOut(400, function() {
                            $(this).remove();
                        });
                    } else {
                        showAlert(response.error || 'Failed to delete student', 'danger');
                        button.prop('disabled', false);
                    }
                },
                error: function(xhr) {
                    const errorMsg = xhr.responseJSON?.error || 'Failed to delete student';
                    showAlert(errorMsg, 'danger');
                    button.prop('disabled', false);
                }
            });
        }
    });
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const clearSearch = document.getElementById('clearSearch');
    const table = document.querySelector('table');
    const tbody = table.querySelector('tbody');
    const rows = tbody.getElementsByTagName('tr');

    function filterTable(searchTerm) {
        searchTerm = searchTerm.toLowerCase();
        
        Array.from(rows).forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    }

    // Search input event
    searchInput.addEventListener('input', function() {
        filterTable(this.value);
    });

    // Clear search
    clearSearch.addEventListener('click', function() {
        searchInput.value = '';
        filterTable('');
        searchInput.focus();
    });

    // Add keyboard shortcut (Ctrl + /)
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === '/') {
            e.preventDefault();
            searchInput.focus();
        }
    });
});
</script>

<style>
#searchInput:focus {
    box-shadow: none;
    border-color: #0d6efd;
}

.input-group .btn-outline-secondary {
    border-color: #ced4da;
}

.input-group .btn-outline-secondary:hover {
    background-color: #e9ecef;
    border-color: #ced4da;
    color: #000;
}
</style>

<script>
let checkIdTimeout;
const studentIdInput = document.getElementById('studentId');
const indicator = document.getElementById('idAvailabilityIndicator');
const message = document.getElementById('idAvailabilityMessage');
const submitButton = document.querySelector('#addStudentModal button[type="submit"]');

studentIdInput.addEventListener('input', function() {
    const studentId = this.value.trim();
    
    // Clear previous timeout
    clearTimeout(checkIdTimeout);
    
    // Reset indicator
    indicator.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    message.textContent = '';
    
    if (studentId.length > 0) {
        // Show loading spinner
        indicator.querySelector('.fa-spinner').style.display = 'inline-block';
        
        // Set timeout for API call
        checkIdTimeout = setTimeout(() => {
            checkStudentIdAvailability(studentId);
        }, 500);
    } else {
        indicator.innerHTML = '';
        submitButton.disabled = false;
    }
});

function checkStudentIdAvailability(studentId) {
    fetch(BASE_URL + '/admin/api/check_student_id.php?student_id=' + encodeURIComponent(studentId))
        .then(response => response.json())
        .then(data => {
            if (data.available) {
                indicator.innerHTML = '<i class="fas fa-check text-success"></i>';
                message.textContent = 'Student ID is available';
                message.className = 'text-success small';
                submitButton.disabled = false;
            } else {
                indicator.innerHTML = '<i class="fas fa-times text-danger"></i>';
                message.textContent = 'Student ID is already taken';
                message.className = 'text-danger small';
                submitButton.disabled = true;
                
                // Show toast
                showToast('This Student ID is already taken. Please choose another.', 'warning');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            indicator.innerHTML = '<i class="fas fa-exclamation-triangle text-warning"></i>';
            message.textContent = 'Error checking availability';
            message.className = 'text-warning small';
        });
}

// Add this if you don't already have a toast function
function showToast(message, type = 'warning') {
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0 show`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    const toastContainer = document.querySelector('.toast-container') || createToastContainer();
    toastContainer.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function createToastContainer() {
    const container = document.createElement('div');
    container.className = 'toast-container position-fixed top-0 end-0 p-3';
    document.body.appendChild(container);
    return container;
}
</script>

<style>
.toast-container {
    z-index: 1060;
}
.input-group-text {
    min-width: 40px;
    justify-content: center;
}
</style>

<?php include '../includes/footer.php'; ?> 