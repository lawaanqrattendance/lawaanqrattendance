<?php
include '../includes/header.php';
requireLogin();

if (getUserRole() !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Handle form submission with resubmission prevention
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $subject_name = cleanInput($_POST['subject_name']);
                $description = cleanInput($_POST['description']);
                
                $stmt = $conn->prepare("INSERT INTO subjects (subject_name, description) VALUES (?, ?)");
                $stmt->bind_param("ss", $subject_name, $description);
                
                if ($stmt->execute()) {
                    $_SESSION['success'] = "Subject added successfully!";
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                } else {
                    $_SESSION['error'] = "Error adding subject.";
                }
                break;
        }
    }
}

// Display session messages
if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
    echo $_SESSION['success'];
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
    unset($_SESSION['success']);
}

if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
    echo $_SESSION['error'];
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
    unset($_SESSION['error']);
}

// Get all subjects
$query = "SELECT * FROM subjects ORDER BY subject_name";
$subjects = $conn->query($query);
?>

<div class="row mb-4">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <h2>Manage Subjects</h2>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSubjectModal">
            Add New Subject
        </button>
    </div>
</div>

<!-- Subjects Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Subject Name</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $counter = 1; // Initialize counter
                    while ($subject = $subjects->fetch_assoc()): 
                    ?>
                        <tr>
                            <td><?php echo $counter++; ?></td>
                            <td><?php echo $subject['subject_name']; ?></td>
                            <td><?php echo htmlspecialchars($subject['description'] ?? ''); ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-subject" 
                                        data-id="<?php echo $subject['subject_id']; ?>"
                                        data-name="<?php echo $subject['subject_name']; ?>"
                                        data-description="<?php echo htmlspecialchars($subject['description'] ?? ''); ?>">
                                    Edit
                                </button>
                                <button class="btn btn-sm btn-danger delete-subject" 
                                        data-id="<?php echo $subject['subject_id']; ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Subject Modal -->
<div class="modal fade" id="addSubjectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Subject</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="subject_name" class="form-label">Subject Name</label>
                        <input type="text" class="form-control" id="subject_name" name="subject_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Subject</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Edit Modal -->
<div class="modal fade" id="editSubjectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Subject</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editSubjectForm">
                <div class="modal-body">
                    <input type="hidden" name="subject_id" id="edit_subject_id">
                    
                    <div class="mb-3">
                        <label class="form-label">Subject Name</label>
                        <input type="text" class="form-control" name="subject_name" id="edit_subject_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="edit_description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add JavaScript -->
<script>
$(document).ready(function() {
    function showAlert(message, type = 'success') {
        const alert = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">')
            .text(message)
            .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
        
        $('.row:first').after(alert);
        
        setTimeout(() => {
            alert.alert('close');
        }, 3000);
    }

    // Edit Subject
    $('.edit-subject').click(function() {
        const button = $(this);
        const id = button.data('id');
        const name = button.data('name');
        const description = button.data('description');
        
        $('#edit_subject_id').val(id);
        $('#edit_subject_name').val(name);
        $('#edit_description').val(description);
        
        $('#editSubjectModal').modal('show');
    });
    
    $('#editSubjectForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/api/update_subject.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                $('#editSubjectModal').modal('hide');
                if (response.success) {
                    showAlert('Subject updated successfully!');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    showAlert(response.error || 'Failed to update subject', 'danger');
                }
            },
            error: function(xhr) {
                $('#editSubjectModal').modal('hide');
                const errorMsg = xhr.responseJSON?.error || 'Failed to update subject';
                showAlert(errorMsg, 'danger');
            }
        });
    });
    
    // Delete Subject
    $('.delete-subject').click(function() {
        if (confirm('Are you sure you want to delete this subject? This will also delete all related schedules.')) {
            const button = $(this);
            const id = button.data('id');
            
            button.prop('disabled', true);
            
            $.ajax({
                url: '<?php echo BASE_URL; ?>/admin/api/delete_subject.php',
                method: 'POST',
                data: { subject_id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showAlert('Subject deleted successfully!');
                        button.closest('tr').fadeOut(400, function() {
                            $(this).remove();
                        });
                    } else {
                        showAlert(response.error || 'Failed to delete subject', 'danger');
                        button.prop('disabled', false);
                    }
                },
                error: function(xhr) {
                    const errorMsg = xhr.responseJSON?.error || 'Failed to delete subject';
                    showAlert(errorMsg, 'danger');
                    button.prop('disabled', false);
                }
            });
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>
