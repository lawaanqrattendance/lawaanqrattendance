<?php
include '../../includes/header.php';
requireLogin();

if (getUserRole() !== 'student') {
    header("Location: " . BASE_URL . "/index.php");
    exit();
}

$student_id = $_SESSION['student_id'];
$current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$records_per_page = 10;
$offset = ($current_page - 1) * $records_per_page;

// Get total records for pagination
$total_query = "SELECT COUNT(*) as total FROM attendance a 
                JOIN schedules s ON a.schedule_id = s.schedule_id
                JOIN subjects sub ON s.subject_id = sub.subject_id
                WHERE a.student_id = ?";
$stmt = $conn->prepare($total_query);
$stmt->bind_param("s", $student_id);
$stmt->execute();
$total_records = $stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_records / $records_per_page);

// Get attendance records
$query = "SELECT a.attendance_date, a.status, a.created_at as time_recorded,
          sub.subject_name, s.start_time, s.end_time,
          CONCAT(t.lastname, ', ', t.firstname) as teacher_name
          FROM attendance a 
          JOIN schedules s ON a.schedule_id = s.schedule_id
          JOIN subjects sub ON s.subject_id = sub.subject_id
          JOIN teachers t ON s.teacher_id = t.teacher_id
          WHERE a.student_id = ?
          ORDER BY a.attendance_date DESC, s.start_time DESC
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("sii", $student_id, $records_per_page, $offset);
$stmt->execute();
$records = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Records</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4>My Attendance Records</h4>
                <a href="<?php echo BASE_URL; ?>/admin/student/dashboard.php" class="btn btn-primary">
                    <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                </a>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Subject</th>
                                    <th>Time</th>
                                    <th>Teacher</th>
                                    <th>Status</th>
                                    <th>Time Recorded</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($record = $records->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo date('M j, Y', strtotime($record['attendance_date'])); ?></td>
                                        <td><?php echo htmlspecialchars($record['subject_name']); ?></td>
                                        <td><?php echo date('g:i A', strtotime($record['start_time'])) . ' - ' . 
                                                   date('g:i A', strtotime($record['end_time'])); ?></td>
                                        <td><?php echo htmlspecialchars($record['teacher_name']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $record['status'] === 'Present' ? 'success' : 
                                                    ($record['status'] === 'Late' ? 'warning' : 'danger'); 
                                            ?>">
                                                <?php echo $record['status']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('g:i A', strtotime($record['time_recorded'])); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i === $current_page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php include '../../includes/footer.php'; ?> 