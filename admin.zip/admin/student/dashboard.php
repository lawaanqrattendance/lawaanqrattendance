<?php
include '../../includes/header.php';
requireLogin();

if (getUserRole() !== 'student') {
    header("Location: " . BASE_URL . "/index.php");
    exit();
}

// Check if email verification is required
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT u.email_verified, u.verification_date, s.email 
                       FROM users u 
                       JOIN students s ON u.reference_id = s.student_id 
                       WHERE u.user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Check if verification has expired (e.g., after 30 days)
$verification_expired = false;
if ($user['email_verified'] && $user['verification_date']) {
    $verification_date = new DateTime($user['verification_date']);
    $now = new DateTime();
    $interval = $verification_date->diff($now);
    
    if ($interval->days > 30) { // Set to your preferred expiration period
        $verification_expired = true;
        
        // Reset verification status
        $stmt = $conn->prepare("UPDATE users SET email_verified = 0 WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
    }
}

if (!$user['email_verified'] || $verification_expired) {
    header("Location: " . BASE_URL . "/admin/student/verify-email.php");
    exit();
}

// Get student_id from users table if not in session
if (!isset($_SESSION['student_id'])) {
    $stmt = $conn->prepare("SELECT reference_id FROM users WHERE user_id = ? AND role = 'student'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $_SESSION['student_id'] = $row['reference_id'];
    } else {
        // Handle error - student not found
        header("Location: " . BASE_URL . "/index.php");
        exit();
    }
}

$student_id = $_SESSION['student_id'];
$current_date = date('Y-m-d');
$day_of_week = date('l'); // Gets current day name

// Get student's schedule for today
$query = "SELECT s.*, 
          sub.subject_name,
          CONCAT(t.lastname, ', ', t.firstname) as teacher_name,
          a.status as attendance_status,
          a.created_at as attendance_time
          FROM schedules s
          JOIN subjects sub ON s.subject_id = sub.subject_id
          JOIN teachers t ON s.teacher_id = t.teacher_id
          LEFT JOIN attendance a ON s.schedule_id = a.schedule_id 
            AND a.student_id = ? 
            AND a.attendance_date = ?
          WHERE s.section_id = (SELECT section_id FROM students WHERE student_id = ?)
          AND s.day_of_week = ?
          ORDER BY s.start_time";

$stmt = $conn->prepare($query);
$stmt->bind_param("ssss", $student_id, $current_date, $student_id, $day_of_week);
$stmt->execute();
$schedules = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Add PWA meta tags -->
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="manifest" href="<?php echo BASE_URL; ?>/manifest.json">
    <title>Student Dashboard</title>
    
    <!-- Add iOS support -->
    <link rel="apple-touch-icon" href="<?php echo BASE_URL; ?>/icons/icon-192x192.png">
    <meta name="apple-mobile-web-app-status-bar" content="#0d6efd">
    <meta name="theme-color" content="#0d6efd">
    
    <!-- Existing styles and scripts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/html5-qrcode"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Add install prompt script -->
    <script>
        // Check if service worker is supported
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('<?php echo BASE_URL; ?>/sw.js')
            .then((reg) => console.log('Service worker registered'))
            .catch((err) => console.log('Service worker not registered', err));
        }

        // Handle install prompt
        let deferredPrompt;
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            // Show install button or prompt
            document.getElementById('installBtn').style.display = 'block';
        });
    </script>
    <style>
        /* Mobile-first styles */
        body {
            background-color: #f8f9fa;
        }
        .schedule-card {
            border-radius: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .schedule-card.current {
            border: 2px solid #0d6efd;
        }
        .qr-container {
            width: 100%;
            max-width: 300px;
            margin: 0 auto;
            position: relative;
        }
        #reader {
            width: 100% !important;
            border-radius: 15px;
            overflow: hidden;
        }
        .scan-result {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1000;
            width: 90%;
            max-width: 400px;
        }
        /* Hide desktop elements on mobile */
        @media (max-width: 768px) {
            .container {
                padding-left: 10px;
                padding-right: 10px;
            }
            .navbar-brand {
                font-size: 1rem;
            }
        }
        /* Add these styles to your existing styles */
        .toast-container {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 1060;  /* Higher than Bootstrap's modal z-index */
            width: 90%;
            max-width: 400px;
        }
        
        .toast {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            transition: opacity 0.3s ease-out;
            opacity: 0;
        }
        
        .toast.success {
            border-left: 4px solid #198754;
        }
        
        .toast.warning {
            border-left: 4px solid #ffc107;
        }
        
        .toast.danger {
            border-left: 4px solid #dc3545;
        }

        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1070;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .loading-content {
            text-align: center;
        }

        .navbar {
            position: sticky;
            top: 0;
            z-index: 1100;
        }

        #changePasswordModal {
            z-index: 1110;
        }
    </style>
</head>
<body>

<!-- Password Change Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Change Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="changePasswordForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Current Password</label>
                        <input type="password" class="form-control" name="current_password" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" class="form-control" name="new_password" 
                               minlength="8" required>
                        <div class="form-text">Password must be at least 8 characters long</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" class="form-control" name="confirm_password" 
                               minlength="8" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4 class="mb-0">Today's Schedule</h4>
                <div class="d-flex align-items-center">
                    <!-- Attendance Records Button -->
                    <a href="<?php echo BASE_URL; ?>/admin/student/attendance_records.php" 
                       class="btn btn-outline-primary btn-sm me-3">
                        <i class="fas fa-history me-2"></i>Attendance Records
                    </a>
                    
                    <!-- Settings Dropdown -->
                    <div class="dropdown">
                        <a class="text-dark" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-cog fs-5"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" style="background-color: #198754;">
                            <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#changePasswordModal" style="color: white !important;">
                                <i class="fas fa-key me-2"></i>Change Password
                            </a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="text-muted mb-3">
                <?php echo date('l, F j, Y'); ?>
            </div>

            <!-- QR Scanner -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Scan Attendance QR</h5>
                    <div class="qr-container">
                        <div id="reader"></div>
                    </div>
                </div>
            </div>

            <!-- Schedule Cards -->
            <div id="scheduleContainer">
                <?php while ($schedule = $schedules->fetch_assoc()): 
                    $start_time = strtotime($schedule['start_time']);
                    $end_time = strtotime($schedule['end_time']);
                    $current_time = strtotime(date('H:i:s'));
                    $is_current = ($current_time >= $start_time && $current_time <= $end_time);
                ?>
                    <div class="card schedule-card <?php echo $is_current ? 'current' : ''; ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <h5 class="card-title mb-1"><?php echo $schedule['subject_name']; ?></h5>
                                    <p class="text-muted mb-1">
                                        <?php echo date('h:i A', $start_time) . ' - ' . date('h:i A', $end_time); ?>
                                    </p>
                                    <small class="text-muted"><?php echo $schedule['teacher_name']; ?></small>
                                </div>
                                <div class="text-end">
                                    <span class="attendance-status" data-schedule-id="<?php echo $schedule['schedule_id']; ?>">
                                        <?php if ($schedule['attendance_status']): ?>
                                            <span class="badge bg-<?php 
                                                echo $schedule['attendance_status'] === 'Present' ? 'success' : 
                                                    ($schedule['attendance_status'] === 'Late' ? 'warning' : 'danger'); 
                                            ?>">
                                                <?php echo $schedule['attendance_status']; ?>
                                            </span>
                                            <br>
                                            <small class="text-muted">
                                                <?php echo date('h:i A', strtotime($schedule['attendance_time'])); ?>
                                            </small>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Not Recorded</span>
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
</div>

<!-- Success/Error Alert -->
<div class="scan-result" style="display: none;"></div>

<!-- Add install button -->
<button id="installBtn" style="display: none;" class="btn btn-primary position-fixed bottom-0 end-0 m-3">
    Install App
</button>

<!-- Add these toast elements before closing body tag -->
<div class="toast-container">
    <div class="toast success" style="display: none;">
        <div>
            <span class="me-2">✅</span>
            <span class="toast-message"></span>
        </div>
    </div>
    <div class="toast warning" style="display: none;">
        <div>
            <span class="me-2">⚠️</span>
            <span class="toast-message"></span>
        </div>
    </div>
    <div class="toast danger" style="display: none;">
        <div>
            <span class="me-2">❌</span>
            <span class="toast-message"></span>
        </div>
    </div>
</div>

<!-- Add this loading overlay HTML after your toast container -->
<div id="loadingOverlay" class="loading-overlay" style="display: none;">
    <div class="loading-content">
        <div class="spinner-border text-light mb-2" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <div class="text-light">Logging out...</div>
    </div>
</div>

<script>
function showToast(message, type = 'success') {
    console.log('Showing toast:', message, type);
    
    const toast = document.querySelector(`.toast.${type}`);
    if (!toast) {
        console.error('Toast element not found!');
        return;
    }
    
    // Set message
    toast.querySelector('.toast-message').textContent = message;
    
    // Show toast
    toast.style.display = 'flex';
    toast.style.opacity = '1';
    
    // For success, show loading overlay and redirect
    if (type === 'success') {
        setTimeout(() => {
            toast.style.opacity = '0';
            document.getElementById('loadingOverlay').style.display = 'flex';
            setTimeout(() => {
                window.location.href = '<?php echo BASE_URL; ?>/auth/logout.php';
            }, 1500); // Redirect after 1.5s of loading animation
        }, 2000); // Show toast for 2s
    } else {
        // For other types, just hide the toast
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 300);
        }, 3000);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const studentId = '<?php echo $student_id; ?>';
    let html5QrcodeScanner = new Html5Qrcode("reader");

    // Add camera permission request button
    const requestCameraBtn = document.createElement('button');
    requestCameraBtn.className = 'btn btn-primary mb-3';
    requestCameraBtn.textContent = 'Enable Camera';
    document.querySelector('.qr-container').prepend(requestCameraBtn);

    requestCameraBtn.addEventListener('click', async () => {
        try {
            // Request camera permission explicitly
            const stream = await navigator.mediaDevices.getUserMedia({ video: true });
            stream.getTracks().forEach(track => track.stop()); // Stop the stream immediately
            
            // Start QR scanner after permission granted
            startScanner();
            requestCameraBtn.style.display = 'none';
        } catch (err) {
            showToast('Camera permission denied. Please enable camera access in your browser settings.', 'warning');
        }
    });

    function startScanner() {
        const config = {
            fps: 10,
            qrbox: { width: 250, height: 250 },
            aspectRatio: 1.0
        };

        html5QrcodeScanner.start(
            { facingMode: "environment" },
            config,
            onScanSuccess,
            onScanError
        );
    }

    // Modify the onScanSuccess handler
    function onScanSuccess(decodedText) {
        console.log('QR Code scanned:', decodedText); // Debug log
        
        if (decodedText === studentId) {
            html5QrcodeScanner.pause();
            
            fetch('<?php echo BASE_URL; ?>/admin/student/api/record_attendance.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    student_id: studentId,
                    qr_code: decodedText
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('Attendance recorded successfully! ✨', 'success');
                    console.log('Success toast shown'); // Debug log
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else {
                    showToast(data.error || 'Failed to record attendance', 'danger');
                    console.log('Error toast shown'); // Debug log
                    html5QrcodeScanner.resume();
                }
            })
            .catch(error => {
                showToast('Error recording attendance', 'danger');
                console.log('Error toast shown'); // Debug log
                html5QrcodeScanner.resume();
            });
        } else {
            showToast('Invalid QR code! Please scan your assigned QR code.', 'warning');
            console.log('Warning toast shown'); // Debug log
        }
    }

    // Existing error handler
    function onScanError(error) {
        // Handle scan error silently
        console.log('Scan error:', error); // Debug log
    }

    // Install button handler
    document.getElementById('installBtn').addEventListener('click', async () => {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') {
                console.log('App installed');
            }
            deferredPrompt = null;
            document.getElementById('installBtn').style.display = 'none';
        }
    });
});

// Function to refresh schedule and attendance status
function refreshSchedule() {
    fetch('<?php echo BASE_URL; ?>/admin/student/api/get_schedule.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('scheduleContainer').innerHTML = data.html;
            }
        })
        .catch(error => console.error('Error:', error));
}

// Refresh every 2 seconds
setInterval(refreshSchedule, 2000);

$(document).ready(function() {
    $('#changePasswordForm').submit(function(e) {
        e.preventDefault();
        
        const formData = $(this).serialize();
        const form = $(this);
        const submitBtn = form.find('button[type="submit"]');
        
        // Basic validation
        const newPass = form.find('input[name="new_password"]').val();
        const confirmPass = form.find('input[name="confirm_password"]').val();
        
        if (newPass !== confirmPass) {
            showToast('New passwords do not match', 'warning');
            return;
        }
        
        // Disable form while processing
        submitBtn.prop('disabled', true);
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/student/api/change_password.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#changePasswordModal').modal('hide');
                    form[0].reset();
                    showToast('Password changed successfully!', 'success');
                } else {
                    showToast(response.error || 'Failed to change password', 'danger');
                }
            },
            error: function() {
                showToast('Failed to change password', 'danger');
            },
            complete: function() {
                submitBtn.prop('disabled', false);
            }
        });
    });
});
</script>

<?php include '../../includes/footer.php'; ?>
