<?php
include '../includes/header.php';
requireLogin();

// Check if user is admin or teacher
$userRole = getUserRole();
if ($userRole !== 'admin' && $userRole !== 'teacher') {
    header("Location: ../index.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $firstname = cleanInput($_POST['firstname']);
                $lastname = cleanInput($_POST['lastname']);
                $middlename = cleanInput($_POST['middlename']);
                $password = $_POST['password'];
                $confirm_password = $_POST['confirm_password'];
                $sections = isset($_POST['sections']) ? $_POST['sections'] : [];
                
                if ($password !== $confirm_password) {
                    $_SESSION['error'] = "Passwords do not match.";
                    break;
                }
                
                try {
                    $conn->begin_transaction();
                    
                    // Insert into teachers table
                    $stmt = $conn->prepare("INSERT INTO teachers (firstname, lastname, middlename) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $firstname, $lastname, $middlename);
                    
                    if ($stmt->execute()) {
                        $teacher_id = $conn->insert_id;
                        
                        // Insert section assignments
                        if (!empty($sections)) {
                            $stmt = $conn->prepare("INSERT INTO teacher_sections (teacher_id, section_id) VALUES (?, ?)");
                            foreach ($sections as $section_id) {
                                $stmt->bind_param("ii", $teacher_id, $section_id);
                                $stmt->execute();
                            }
                        }
                        
                        // Create username (firstname.lastname)
                        $username = strtolower($firstname . '.' . $lastname);
                        
                        // Check if username exists and append number if needed
                        $count = 1;
                        $original_username = $username;
                        while (true) {
                            $check = $conn->prepare("SELECT username FROM users WHERE username = ?");
                            $check->bind_param("s", $username);
                            $check->execute();
                            if ($check->get_result()->num_rows === 0) {
                                break;
                            }
                            $username = $original_username . $count;
                            $count++;
                        }
                        
                        // Hash password and create user account
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $conn->prepare("INSERT INTO users (username, password, role, reference_id) VALUES (?, ?, 'teacher', ?)");
                        $stmt->bind_param("sss", $username, $hashed_password, $teacher_id);
                        $stmt->execute();
                        
                        $conn->commit();
                        $_SESSION['success'] = "Teacher added successfully! Username: " . $username;
                        header("Location: " . $_SERVER['PHP_SELF']);
                        exit();
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                    $_SESSION['error'] = "Error adding teacher: " . $e->getMessage();
                }
                break;
        }
    }
}

// Get all teachers
$query = "SELECT t.*, u.username 
          FROM teachers t 
          LEFT JOIN users u ON t.teacher_id = u.reference_id AND u.role = 'teacher' 
          ORDER BY t.lastname, t.firstname";
$teachers = $conn->query($query);

// Then display alerts from session
if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
    echo $_SESSION['success'];
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
    unset($_SESSION['success']);
}

if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
    echo $_SESSION['error'];
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
    unset($_SESSION['error']);
}
?>

<div class="row mb-4">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <h2>Manage Teachers</h2>
        <?php if ($userRole === 'admin'): ?>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTeacherModal">
                Add New Teacher
            </button>
        <?php endif; ?>
    </div>
</div>

<!-- Teachers Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Assigned Sections</th>
                        <?php if ($userRole === 'admin'): ?>
                            <th>Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($teacher = $teachers->fetch_assoc()): ?>
                        <?php
                        // Get assigned sections
                        $stmt = $conn->prepare("SELECT s.grade_level, s.section_name 
                                               FROM teacher_sections ts 
                                               JOIN sections s ON ts.section_id = s.section_id 
                                               WHERE ts.teacher_id = ?
                                               ORDER BY s.grade_level, s.section_name");
                        $stmt->bind_param("i", $teacher['teacher_id']);
                        $stmt->execute();
                        $sections = $stmt->get_result();
                        
                        $section_list = [];
                        while ($section = $sections->fetch_assoc()) {
                            $section_list[] = "Grade {$section['grade_level']}-{$section['section_name']}";
                        }
                        ?>
                        <tr>
                            <td><?php echo $teacher['teacher_id']; ?></td>
                            <td><?php echo $teacher['lastname'] . ', ' . $teacher['firstname']; ?></td>
                            <td><?php echo $teacher['username'] ?? 'No account'; ?></td>
                            <td>
                                <?php 
                                if (count($section_list) > 3) {
                                    echo count($section_list) . " sections";
                                } else {
                                    echo implode(", ", $section_list) ?: 'No sections assigned';
                                }
                                ?>
                            </td>
                            <?php if ($userRole === 'admin'): ?>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm edit-teacher" 
                                            data-teacher-id="<?php echo $teacher['teacher_id']; ?>"
                                            data-firstname="<?php echo $teacher['firstname']; ?>"
                                            data-lastname="<?php echo $teacher['lastname']; ?>"
                                            data-middlename="<?php echo $teacher['middlename']; ?>">
                                        Edit
                                    </button>
                                    <button class="btn btn-sm btn-danger delete-teacher" 
                                            data-id="<?php echo $teacher['teacher_id']; ?>">
                                        Delete
                                    </button>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($userRole === 'admin'): ?>
    <!-- Add Teacher Modal -->
    <div class="modal fade" id="addTeacherModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Teacher</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="firstname" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lastname" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Middle Name</label>
                            <input type="text" class="form-control" name="middlename">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Assign Sections</label>
                            <select class="form-select section-select-add" name="sections[]" multiple required>
                                <?php
                                $sections_query = "SELECT section_id, grade_level, section_name 
                                                  FROM sections 
                                                  ORDER BY grade_level, section_name";
                                $sections = $conn->query($sections_query);
                                $current_grade = null;
                                
                                while ($section = $sections->fetch_assoc()):
                                    if ($current_grade !== $section['grade_level']):
                                        if ($current_grade !== null) echo '</optgroup>';
                                        $current_grade = $section['grade_level'];
                                        echo "<optgroup label='Grade {$section['grade_level']}'>";
                                    endif;
                                ?>
                                    <option value="<?php echo $section['section_id']; ?>">
                                        <?php echo $section['section_name']; ?>
                                    </option>
                                <?php 
                                endwhile;
                                if ($current_grade !== null) echo '</optgroup>';
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add Teacher</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Teacher Modal -->
    <div class="modal fade" id="editTeacherModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Teacher</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="editTeacherForm">
                    <div class="modal-body">
                        <input type="hidden" name="teacher_id" id="edit_teacher_id">
                        
                        <div class="mb-3">
                            <label class="form-label">First Name</label>
                            <input type="text" class="form-control" name="firstname" id="edit_firstname" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Last Name</label>
                            <input type="text" class="form-control" name="lastname" id="edit_lastname" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Middle Name</label>
                            <input type="text" class="form-control" name="middlename" id="edit_middlename">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" class="form-control" name="password" id="edit_password" placeholder="Leave blank to keep current password">
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" name="confirm_password" id="edit_confirm_password" placeholder="Leave blank to keep current password">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Assign Sections</label>
                            <select class="form-select section-select" name="sections[]" multiple required style="z-index: 100 !important;">
                                <?php
                                $sections_query = "SELECT section_id, grade_level, section_name 
                                                  FROM sections 
                                                  ORDER BY grade_level, section_name";
                                $sections = $conn->query($sections_query);
                                $current_grade = null;
                                
                                while ($section = $sections->fetch_assoc()):
                                    if ($current_grade !== $section['grade_level']):
                                        if ($current_grade !== null) echo '</optgroup>';
                                        $current_grade = $section['grade_level'];
                                        echo "<optgroup label='Grade {$section['grade_level']}'>";
                                    endif;
                                ?>
                                    <option value="<?php echo $section['section_id']; ?>">
                                        <?php echo $section['section_name']; ?>
                                    </option>
                                <?php 
                                endwhile;
                                if ($current_grade !== null) echo '</optgroup>';
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Add JavaScript -->
    <script>
    $(document).ready(function() {
        // Function to show alerts
        function showAlert(message, type = 'success') {
            const alert = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">')
                .text(message)
                .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
            
            $('.row:first').after(alert);
            
            // Auto dismiss after 3 seconds
            setTimeout(() => {
                alert.alert('close');
            }, 3000);
        }

        // Initialize Select2 with dropdown parent specified
        $('.section-select').select2({
            placeholder: 'Select sections',
            allowClear: true,
            width: '100%',
            dropdownParent: $('#editTeacherModal') // Specify the parent modal
        });

        // For the add teacher modal
        $('.section-select-add').select2({
            placeholder: 'Select sections',
            allowClear: true,
            width: '100%',
            dropdownParent: $('#addTeacherModal') // Specify the parent modal
        });

        // Edit Teacher
        $('.edit-teacher').click(function() {
            const button = $(this);
            const id = button.data('teacher-id');
            const firstname = button.data('firstname');
            const lastname = button.data('lastname');
            const middlename = button.data('middlename');
            
            $('#edit_teacher_id').val(id);
            $('#edit_firstname').val(firstname);
            $('#edit_lastname').val(lastname);
            $('#edit_middlename').val(middlename);
            
            // Clear previous selections
            $('.section-select').val(null).trigger('change');
            
            // Get assigned sections
            $.ajax({
                url: '<?php echo BASE_URL; ?>/admin/api/get_teacher_sections.php',
                method: 'GET',
                data: { teacher_id: id },
                success: function(response) {
                    // Parse the response if it's a string
                    const sections = typeof response === 'string' ? JSON.parse(response) : response;
                    // Set the values and trigger change for Select2
                    $('.section-select').val(sections).trigger('change');
                },
                error: function(xhr) {
                    showAlert('Failed to load teacher sections', 'danger');
                }
            });
            
            $('#editTeacherModal').modal('show');
        });
        
        $('#editTeacherForm').submit(function(e) {
            e.preventDefault();
            const formData = $(this).serialize();
            
            $.ajax({
                url: '<?php echo BASE_URL; ?>/admin/api/update_teacher.php',
                method: 'POST',
                data: formData,
                dataType: 'json',
                success: function(response) {
                    $('#editTeacherModal').modal('hide');
                    if (response.success) {
                        showAlert('Teacher updated successfully!');
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        showAlert(response.error || 'Failed to update teacher', 'danger');
                    }
                },
                error: function(xhr) {
                    $('#editTeacherModal').modal('hide');
                    const errorMsg = xhr.responseJSON?.error || 'Failed to update teacher';
                    showAlert(errorMsg, 'danger');
                }
            });
        });
        
        // Delete Teacher
        $('.delete-teacher').click(function() {
            if (confirm('Are you sure you want to delete this teacher? This will also delete their user account and all related records.')) {
                const button = $(this);
                const id = button.data('id');
                
                // Disable button while processing
                button.prop('disabled', true);
                
                $.ajax({
                    url: '<?php echo BASE_URL; ?>/admin/api/delete_teacher.php',
                    method: 'POST',
                    data: { teacher_id: id },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            showAlert('Teacher deleted successfully!');
                            button.closest('tr').fadeOut(400, function() {
                                $(this).remove();
                            });
                        } else {
                            showAlert(response.error || 'Failed to delete teacher', 'danger');
                            button.prop('disabled', false);
                        }
                    },
                    error: function(xhr) {
                        const errorMsg = xhr.responseJSON?.error || 'Failed to delete teacher';
                        showAlert(errorMsg, 'danger');
                        button.prop('disabled', false);
                    }
                });
            }
        });
    });
    </script>
<?php endif; ?>

<?php include '../includes/footer.php'; ?>

<!-- Add this to your <head> section or before </body> -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script> 