<?php
require_once __DIR__ . '/../vendor/autoload.php';
include '../includes/header.php';
requireLogin();

if (getUserRole() !== 'admin') {
    header("Location: " . BASE_URL . "/index.php");
    exit();
}

// Include Endroid QR Code library
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\ErrorCorrectionLevel\ErrorCorrectionLevelHigh;

// Create QR code directory if it doesn't exist
$qr_directory = "../qr_codes";
if (!file_exists($qr_directory)) {
    mkdir($qr_directory, 0777, true);
}

// Function to generate QR code
function generateQRCode($data, $file_path) {
    $qr = QrCode::create($data)
        ->setErrorCorrectionLevel(new ErrorCorrectionLevelHigh())
        ->setSize(300)
        ->setMargin(10);
    
    $writer = new PngWriter();
    $result = $writer->write($qr);
    $result->saveToFile($file_path);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'generate_single':
                $student_id = cleanInput($_POST['student_id']);
                
                // Generate QR code
                $file_name = $qr_directory . "/qr_" . $student_id . ".png";
                generateQRCode($student_id, $file_name);
                
                $_SESSION['success_message'] = "QR code generated for student ID: " . $student_id;
                $_SESSION['generated_file'] = $file_name;
                
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
                
            case 'generate_bulk':
                $section_id = cleanInput($_POST['section_id']);
                
                // Create section directory
                $section_dir = $qr_directory . "/section_" . $section_id;
                if (!file_exists($section_dir)) {
                    mkdir($section_dir, 0777, true);
                }
                
                // Get all students in section
                $stmt = $conn->prepare("SELECT student_id, firstname, lastname FROM students WHERE section_id = ?");
                $stmt->bind_param("i", $section_id);
                $stmt->execute();
                $students = $stmt->get_result();
                
                $generated_count = 0;
                while ($student = $students->fetch_assoc()) {
                    $file_name = $section_dir . "/qr_" . $student['student_id'] . ".png";
                    generateQRCode($student['student_id'], $file_name);
                    $generated_count++;
                }
                
                // Create ZIP archive
                $zip = new ZipArchive();
                $zip_file = $qr_directory . "/section_" . $section_id . "_qrcodes.zip";
                
                if ($zip->open($zip_file, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                    $files = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($section_dir),
                        RecursiveIteratorIterator::LEAVES_ONLY
                    );
                    
                    foreach ($files as $file) {
                        if (!$file->isDir()) {
                            $zip->addFile($file->getRealPath(), basename($file->getRealPath()));
                        }
                    }
                    
                    $zip->close();
                    $_SESSION['success_message'] = "Generated " . $generated_count . " QR codes. Download ZIP file below.";
                    $_SESSION['generated_zip'] = $zip_file;
                }
                
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
                
            case 'clean_folder':
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($qr_directory),
                    RecursiveIteratorIterator::LEAVES_ONLY
                );
                
                foreach ($files as $file) {
                    if ($file->isFile() && ($file->getExtension() === 'png' || $file->getExtension() === 'zip')) {
                        unlink($file->getRealPath());
                    }
                }
                
                $_SESSION['success_message'] = "QR code folder cleaned successfully!";
                
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
        }
    }
}

// At the top of the page, after session start
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['generated_file'])) {
    $generated_file = $_SESSION['generated_file'];
    unset($_SESSION['generated_file']);
}

if (isset($_SESSION['generated_zip'])) {
    $generated_zip = $_SESSION['generated_zip'];
    unset($_SESSION['generated_zip']);
}

// Get all sections for dropdown
$sections = $conn->query("SELECT * FROM sections ORDER BY grade_level, section_name");
?>

<!-- Add Select2 CSS and JS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<div class="row mb-4">
    <div class="col-md-12">
        <h2>Generate QR Codes</h2>
    </div>
</div>

<?php if (isset($success)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success; ?>
        <?php if (isset($generated_file)): ?>
            <br>
            <a href="<?php echo str_replace("..", BASE_URL, $generated_file); ?>" 
               class="btn btn-sm btn-primary mt-2" download>
                Download QR Code
            </a>
        <?php endif; ?>
        <?php if (isset($generated_zip)): ?>
            <br>
            <a href="<?php echo str_replace("..", BASE_URL, $generated_zip); ?>" 
               class="btn btn-sm btn-primary mt-2" download>
                Download ZIP File
            </a>
        <?php endif; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row">
    <!-- Single QR Code Generation -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Generate Single QR Code</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="generate_single">
                    
                    <div class="mb-3">
                        <label class="form-label">Student ID</label>
                        <input type="text" class="form-control" name="student_id" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Generate QR Code</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Bulk QR Code Generation -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Generate QR Codes for Section</h5>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="generate_bulk">
                    
                    <div class="mb-3">
                        <label class="form-label">Select Section</label>
                        <select name="section_id" class="form-select select2" required>
                            <option value="">Choose Section...</option>
                            <?php 
                            $sections = $conn->query("SELECT s.*, 
                                (SELECT COUNT(*) FROM students WHERE section_id = s.section_id) as student_count 
                                FROM sections s 
                                ORDER BY grade_level, section_name");
                            
                            while ($section = $sections->fetch_assoc()): 
                            ?>
                                <option value="<?php echo $section['section_id']; ?>">
                                    Grade <?php echo $section['grade_level']; ?> - 
                                    <?php echo $section['section_name']; ?> 
                                    (<?php echo $section['student_count']; ?> students)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Generate QR Codes</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- QR Code Preview -->
<?php if (isset($generated_file)): ?>
<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">QR Code Preview</h5>
            </div>
            <div class="card-body text-center">
                <img src="<?php echo str_replace("..", BASE_URL, $generated_file); ?>" 
                     alt="Generated QR Code" class="img-fluid">
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Manage QR Files -->
<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Generated QR Files</h5>
                <form method="POST" class="d-inline">
                    <input type="hidden" name="action" value="clean_folder">
                    <button type="submit" class="btn btn-danger btn-sm" 
                            onclick="return confirm('Are you sure you want to delete all QR files?')">
                        Clean QR Folder
                    </button>
                </form>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>File Name</th>
                                <th>Type</th>
                                <th>Generated</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $files = new RecursiveIteratorIterator(
                                new RecursiveDirectoryIterator($qr_directory),
                                RecursiveIteratorIterator::LEAVES_ONLY
                            );
                            
                            foreach ($files as $file) {
                                if ($file->isFile() && $file->getExtension() === 'png' || $file->getExtension() === 'zip') {
                                    $relativePath = str_replace('..', BASE_URL, $file->getPathname());
                                    ?>
                                    <tr>
                                        <td><?php echo basename($file->getPathname()); ?></td>
                                        <td><?php echo strtoupper($file->getExtension()); ?></td>
                                        <td><?php echo date('Y-m-d H:i:s', $file->getMTime()); ?></td>
                                        <td>
                                            <a href="<?php echo $relativePath; ?>" 
                                               class="btn btn-primary btn-sm" 
                                               download>
                                                Download
                                            </a>
                                            <a href="<?php echo $relativePath; ?>" 
                                               class="btn btn-info btn-sm"
                                               target="_blank">
                                                View
                                            </a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.select2').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'Choose Section...',
        allowClear: true
    });
});
</script>

<?php include '../includes/footer.php'; ?> 
<?php include '../includes/footer.php'; ?> 