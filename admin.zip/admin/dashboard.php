<?php
include '../includes/header.php';
requireLogin();

// Check if user is admin
if (getUserRole() !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Get counts for dashboard
$studentCount = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'];
$teacherCount = $conn->query("SELECT COUNT(*) as count FROM teachers")->fetch_assoc()['count'];
$sectionCount = $conn->query("SELECT COUNT(*) as count FROM sections")->fetch_assoc()['count'];
$subjectCount = $conn->query("SELECT COUNT(*) as count FROM subjects")->fetch_assoc()['count'];
?>

<div class="row mb-4">
    <div class="col-md-12">
        <h2>Admin Dashboard</h2>
    </div>
</div>

<div class="row mb-4">
    <!-- Dashboard Cards -->
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Students</h5>
                <h2 class="card-text"><?php echo $studentCount; ?></h2>
                <a href="manage_students.php" class="text-white">Manage Students →</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <h5 class="card-title">Teachers</h5>
                <h2 class="card-text"><?php echo $teacherCount; ?></h2>
                <a href="manage_teachers.php" class="text-white">Manage Teachers →</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h5 class="card-title">Sections</h5>
                <h2 class="card-text"><?php echo $sectionCount; ?></h2>
                <a href="manage_sections.php" class="text-white">Manage Sections →</a>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <h5 class="card-title">Subjects</h5>
                <h2 class="card-text"><?php echo $subjectCount; ?></h2>
                <a href="manage_subjects.php" class="text-white">Manage Subjects →</a>
            </div>
        </div>
    </div>
</div>

<div class="col-md-12 mt-3 mb-3">
    <div class="card bg-primary text-white">
        <div class="card-body">
            <h5 class="card-title">QR Codes</h5>
            <p class="card-text">Generate QR codes for students</p>
            <a href="<?php echo BASE_URL; ?>/admin/generate_qr.php" class="text-white">Generate QR Codes →</a>
        </div>
    </div>
</div>

<div class="row">
    <!-- Quick Actions -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Quick Actions</h5>
                <div class="list-group">
                    <a href="manage_schedules.php" class="list-group-item list-group-item-action">
                        Manage Class Schedules
                    </a>
                    <!-- <a href="teacher/view_attendance.php" class="list-group-item list-group-item-action">
                        View Attendance Reports
                    </a> -->
                    <a href="manage_users.php" class="list-group-item list-group-item-action">
                        Manage User Accounts
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Recent Activity</h5>
                <div class="list-group">
                    <?php
                    $query = "SELECT a.attendance_date, s.firstname, s.lastname, sub.subject_name 
                             FROM attendance a 
                             JOIN students s ON a.student_id = s.student_id 
                             JOIN schedules sc ON a.schedule_id = sc.schedule_id 
                             JOIN subjects sub ON sc.subject_id = sub.subject_id 
                             ORDER BY a.created_at DESC LIMIT 5";
                    $result = $conn->query($query);
                    
                    while ($row = $result->fetch_assoc()) {
                        echo "<div class='list-group-item'>";
                        echo "<small class='text-muted'>" . date('M d, Y', strtotime($row['attendance_date'])) . "</small><br>";
                        echo $row['firstname'] . " " . $row['lastname'] . " attended " . $row['subject_name'];
                        echo "</div>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-4 mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Calendar & Notes</h5>
            </div>
            <div class="card-body">
                <div id="calendar"></div>
            </div>
        </div>
    </div>
</div>

<!-- Add Note Modal -->
<div class="modal fade" id="addNoteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Note</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="addNoteForm">
                <div class="modal-body">
                    <input type="hidden" id="noteDate" name="note_date">
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" class="form-control" name="note_title" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Content</label>
                        <textarea class="form-control" name="note_content" rows="4" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Note</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View/Edit Note Modal -->
<div class="modal fade" id="viewNoteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Note Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editNoteId">
                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" class="form-control" id="viewNoteTitle">
                </div>
                <div class="mb-3">
                    <label class="form-label">Content</label>
                    <textarea class="form-control" id="viewNoteContent" rows="4"></textarea>
                </div>
                <div class="text-muted small" id="noteTimestamp"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger me-auto" id="deleteNoteBtn">Delete</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="updateNoteBtn">Update</button>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js'></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 'auto',
        selectable: true,
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: '<?php echo BASE_URL; ?>/admin/api/get_notes.php',
        select: function(info) {
            $('#noteDate').val(info.startStr);
            $('#addNoteModal').modal('show');
        },
        eventClick: function(info) {
            const event = info.event;
            $('#editNoteId').val(event.id);
            $('#viewNoteTitle').val(event.title);
            $('#viewNoteContent').val(event.extendedProps.content);
            $('#noteTimestamp').text('Last updated: ' + event.extendedProps.updated_at);
            $('#viewNoteModal').modal('show');
        }
    });
    calendar.render();

    // Add Note Form Handler
    $('#addNoteForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/api/add_note.php',
            method: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $('#addNoteModal').modal('hide');
                    calendar.refetchEvents();
                    showToast('Note added successfully!', 'success', false);
                    window.location.reload();
                } else {
                    showToast(response.error || 'Failed to add note', 'danger');
                }
            },
            error: function() {
                showToast('Failed to add note', 'danger');
            }
        });
    });

    // Update Note Handler
    $('#updateNoteBtn').click(function() {
        const noteId = $('#editNoteId').val();
        const title = $('#viewNoteTitle').val();
        const content = $('#viewNoteContent').val();

        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/api/update_note.php',
            method: 'POST',
            data: {
                note_id: noteId,
                note_title: title,
                note_content: content
            },
            success: function(response) {
                if (response.success) {
                    $('#viewNoteModal').modal('hide');
                    calendar.refetchEvents();
                    showToast('Note updated successfully!', 'success', false);
                    window.location.reload();
                } else {
                    showToast(response.error || 'Failed to update note', 'danger');
                }
            },
            error: function() {
                showToast('Failed to update note', 'danger');
            }
        });
    });

    // Delete Note Handler
    $('#deleteNoteBtn').click(function() {
        if (confirm('Are you sure you want to delete this note?')) {
            const noteId = $('#editNoteId').val();

            $.ajax({
                url: '<?php echo BASE_URL; ?>/admin/api/delete_note.php',
                method: 'POST',
                data: { note_id: noteId },
                success: function(response) {
                    if (response.success) {
                        $('#viewNoteModal').modal('hide');
                        calendar.refetchEvents();
                        showToast('Note deleted successfully!', 'success', false);
                        window.location.reload();
                    } else {
                        showToast(response.error || 'Failed to delete note', 'danger');
                    }
                },
                error: function() {
                    showToast('Failed to delete note', 'danger');
                }
            });
        }
    });
});
</script>

<style>
.fc-event {
    cursor: pointer;
}
.fc-day-today {
    background-color: rgba(13, 110, 253, 0.1) !important;
}
.fc-header-toolbar {
    margin-bottom: 1rem !important;
}
</style>

<!-- Toast Container -->
<div class="toast-container">
    <div class="toast success" style="display: none;">
        <div>
            <span class="me-2">✅</span>
            <span class="toast-message"></span>
        </div>
    </div>
    <div class="toast warning" style="display: none;">
        <div>
            <span class="me-2">⚠️</span>
            <span class="toast-message"></span>
        </div>
    </div>
    <div class="toast danger" style="display: none;">
        <div>
            <span class="me-2">❌</span>
            <span class="toast-message"></span>
        </div>
    </div>
</div>

<style>
/* Toast Styles */
.toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1060;
}

.toast {
    background: white;
    border-radius: 8px;
    padding: 16px 24px;
    margin-bottom: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    display: flex;
    align-items: center;
    transition: opacity 0.3s ease-in-out;
    opacity: 0;
}

.toast.success {
    border-left: 4px solid #198754;
}

.toast.warning {
    border-left: 4px solid #ffc107;
}

.toast.danger {
    border-left: 4px solid #dc3545;
}

.toast-message {
    color: #333;
    font-size: 14px;
}
</style>

<script>
// Toast function
function showToast(message, type = 'success', shouldLogout = false) {
    const toast = document.querySelector(`.toast.${type}`);
    if (!toast) return;
    
    // Set message
    toast.querySelector('.toast-message').textContent = message;
    
    // Show toast
    toast.style.display = 'flex';
    toast.style.opacity = '1';
    
    // For success with logout, show loading overlay and redirect
    if (type === 'success' && shouldLogout) {
        setTimeout(() => {
            toast.style.opacity = '0';
            document.getElementById('loadingOverlay').style.display = 'flex';
            setTimeout(() => {
                window.location.href = '<?php echo BASE_URL; ?>/auth/logout.php';
            }, 1500);
        }, 2000);
    } else {
        // For other types or success without logout, just hide the toast
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 300);
        }, 3000);
    }
}
</script> 