<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';

// Check authentication before including header
if (!isLoggedIn() || getUserRole() !== 'teacher') {
    header("Location: ../../index.php");
    exit();
}

include '../../includes/header.php';

$teacher_id = $_SESSION['teacher_id'];

// Get all sections taught by this teacher
$sections_query = "SELECT DISTINCT s.section_id, s.section_name, s.grade_level 
                  FROM sections s
                  JOIN schedules sch ON s.section_id = sch.section_id
                  WHERE sch.teacher_id = ?
                  ORDER BY s.grade_level, s.section_name";

$stmt = $conn->prepare($sections_query);
$stmt->bind_param("i", $teacher_id);
$stmt->execute();
$sections = $stmt->get_result();
?>

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-12 d-flex justify-content-between align-items-center">
            <h2>Attendance Reports</h2>
            <div>
                <a href="<?php echo BASE_URL; ?>/admin/teacher/dashboard.php" class="btn btn-secondary me-2">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <button type="button" class="btn btn-success" id="exportExcel">
                    <i class="fas fa-file-excel"></i> Export to Excel
                </button>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form id="reportFilters">
                <div class="row">
                    <div class="col-md-3">
                        <label class="form-label">Section</label>
                        <select class="form-select" name="section_id">
                            <option value="">All Sections</option>
                            <?php while ($section = $sections->fetch_assoc()): ?>
                                <option value="<?php echo $section['section_id']; ?>">
                                    Grade <?php echo $section['grade_level'] . ' - ' . $section['section_name']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Date Range</label>
                        <input type="date" class="form-control" name="start_date" value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">To</label>
                        <input type="date" class="form-control" name="end_date" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status">
                            <option value="">All Status</option>
                            <option value="Present">Present</option>
                            <option value="Late">Late</option>
                            <option value="Absent">Absent</option>
                        </select>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Generate Report
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Report Results -->
    <div id="reportResults" style="max-height: 450px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 0.25rem;">
        <!-- Will be populated via AJAX -->
    </div>
</div>

<script>
$(document).ready(function() {
    // Function to load report data
    function loadReport(formData) {
        $.get('<?php echo BASE_URL; ?>/admin/teacher/get_attendance_report.php', formData, function(data) {
            $('#reportResults').html(data);
        });
    }

    // Handle form submission
    $('#reportFilters').submit(function(e) {
        e.preventDefault();
        loadReport($(this).serialize());
    });

    // Export to Excel
    $('#exportExcel').click(function() {
        const formData = $('#reportFilters').serialize() + '&export=excel';
        window.location.href = '<?php echo BASE_URL; ?>/admin/teacher/export_attendance.php?' + formData;
    });

    // Load initial report
    loadReport($('#reportFilters').serialize());
});
</script>

<?php include '../../includes/footer.php'; ?> 