<?php
include '../../includes/header.php';
requireLogin();

// Allow both admin and teacher roles
if (getUserRole() !== 'teacher' && getUserRole() !== 'admin') {
    header("Location: " . BASE_URL . "/index.php");
    exit();
}

// Get teacher_id based on role
$userRole = getUserRole();
if ($userRole === 'teacher') {
    // Fix for reference_id - get teacher_id from users table
    $stmt = $conn->prepare("SELECT reference_id FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $teacher_id = $user['reference_id'];
} else {
    // For admin, use the selected teacher_id from GET parameter
    $teacher_id = isset($_GET['teacher_id']) ? cleanInput($_GET['teacher_id']) : null;
}

$schedule_id = isset($_GET['schedule_id']) ? cleanInput($_GET['schedule_id']) : null;
$date = isset($_GET['date']) ? cleanInput($_GET['date']) : date('Y-m-d');

// Verify this schedule belongs to the teacher (for teacher role)
if ($schedule_id) {
    $stmt = $conn->prepare("SELECT s.*, 
                           sub.subject_name,
                           sec.section_name,
                           sec.grade_level,
                           t.teacher_id
                           FROM schedules s
                           JOIN subjects sub ON s.subject_id = sub.subject_id
                           JOIN sections sec ON s.section_id = sec.section_id
                           JOIN teachers t ON s.teacher_id = t.teacher_id
                           WHERE s.schedule_id = ? " . 
                           ($userRole === 'teacher' ? "AND s.teacher_id = ?" : ""));
    
    if ($userRole === 'teacher') {
        $stmt->bind_param("ii", $schedule_id, $teacher_id);
    } else {
        $stmt->bind_param("i", $schedule_id);
    }
    $stmt->execute();
    $schedule = $stmt->get_result()->fetch_assoc();

    if (!$schedule) {
        header("Location: " . BASE_URL . "/admin/teacher/dashboard.php");
        exit();
    }
}

// Get all schedules for dropdown (filtered by teacher for teacher role)
$schedules_query = "SELECT s.*, 
                    sub.subject_name,
                    sec.section_name,
                    sec.grade_level
                    FROM schedules s
                    JOIN subjects sub ON s.subject_id = sub.subject_id
                    JOIN sections sec ON s.section_id = sec.section_id
                    WHERE 1=1 " .
                    ($userRole === 'teacher' ? "AND s.teacher_id = ? " : "") .
                    "ORDER BY s.day_of_week, s.start_time";

$stmt = $conn->prepare($schedules_query);
if ($userRole === 'teacher') {
    $stmt->bind_param("i", $teacher_id);
}
$stmt->execute();
$all_schedules = $stmt->get_result();

// Get students and their attendance for the selected schedule
if ($schedule_id) {
    $query = "SELECT s.*, 
              COALESCE(a.status, 'Absent') as attendance_status,
              a.attendance_id
              FROM students s
              JOIN sections sec ON s.section_id = sec.section_id
              LEFT JOIN attendance a ON s.student_id = a.student_id 
                AND a.schedule_id = ? 
                AND a.attendance_date = ?
              JOIN schedules sch ON a.schedule_id = sch.schedule_id
              WHERE sec.section_id = ? " .
              ($userRole === 'teacher' ? "AND sch.teacher_id = ? " : "") .
              "ORDER BY s.lastname, s.firstname";
    
    if ($userRole === 'teacher') {
        $stmt = $conn->prepare($query);
        $stmt->bind_param("isii", $schedule_id, $date, $schedule['section_id'], $teacher_id);
    } else {
        $stmt = $conn->prepare($query);
        $stmt->bind_param("isi", $schedule_id, $date, $schedule['section_id']);
    }
    $stmt->execute();
    $students = $stmt->get_result();
}
?>

<div class="row mb-4">
    <div class="col-md-12">
        <h2>Manage Attendance</h2>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                <li class="breadcrumb-item active">Attendance</li>
            </ol>
        </nav>
    </div>
</div>

<!-- Schedule and Date Selection -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Select Schedule</label>
                <select name="schedule_id" class="form-select" required onchange="this.form.submit()">
                    <option value="">Choose Schedule...</option>
                    <?php while ($sch = $all_schedules->fetch_assoc()): ?>
                        <option value="<?php echo $sch['schedule_id']; ?>" 
                                <?php echo ($schedule_id == $sch['schedule_id']) ? 'selected' : ''; ?>>
                            <?php echo $sch['day_of_week'] . ' - ' . 
                                     date('h:i A', strtotime($sch['start_time'])) . ' - ' .
                                     $sch['subject_name'] . ' (Grade ' . 
                                     $sch['grade_level'] . ' - ' . $sch['section_name'] . ')'; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Select Date</label>
                <input type="date" name="date" class="form-control" value="<?php echo $date; ?>" 
                       max="<?php echo date('Y-m-d'); ?>" required onchange="this.form.submit()">
            </div>
        </form>
    </div>
</div>

<?php if ($schedule_id && $students && $students->num_rows > 0): ?>
    <!-- Attendance List -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <?php echo $schedule['subject_name'] . ' - Grade ' . 
                          $schedule['grade_level'] . ' ' . $schedule['section_name']; ?>
            </h5>
            <span class="badge bg-<?php echo $schedule['status'] === 'Open' ? 'success' : 'secondary'; ?>">
                <?php echo $schedule['status']; ?>
            </span>
        </div>
        <div class="card-body">
            <form id="attendanceForm">
                <input type="hidden" name="schedule_id" value="<?php echo $schedule_id; ?>">
                <input type="hidden" name="date" value="<?php echo $date; ?>">
                
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($student = $students->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $student['student_id']; ?></td>
                                    <td><?php echo $student['lastname'] . ', ' . $student['firstname']; ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $student['attendance_status'] === 'Present' ? 'success' : 
                                                ($student['attendance_status'] === 'Late' ? 'warning' : 'danger'); 
                                        ?>">
                                            <?php echo $student['attendance_status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-sm btn-success update-status" 
                                                    data-student="<?php echo $student['student_id']; ?>" 
                                                    data-status="Present">
                                                Present
                                            </button>
                                            <button type="button" class="btn btn-sm btn-warning update-status" 
                                                    data-student="<?php echo $student['student_id']; ?>" 
                                                    data-status="Late">
                                                Late
                                            </button>
                                            <button type="button" class="btn btn-sm btn-danger update-status" 
                                                    data-student="<?php echo $student['student_id']; ?>" 
                                                    data-status="Absent">
                                                Absent
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        $('.update-status').click(function() {
            const button = $(this);
            const studentId = button.data('student');
            const status = button.data('status');
            const row = button.closest('tr');
            
            $.ajax({
                url: '<?php echo BASE_URL; ?>/admin/teacher/api/update_attendance.php',
                method: 'POST',
                data: {
                    student_id: studentId,
                    schedule_id: <?php echo $schedule_id; ?>,
                    attendance_date: '<?php echo $date; ?>',
                    status: status
                },
                success: function(response) {
                    if (response.success) {
                        // Update the status badge
                        const badge = row.find('.badge');
                        badge.removeClass('bg-success bg-warning bg-danger')
                            .addClass(status === 'Present' ? 'bg-success' : 
                                    (status === 'Late' ? 'bg-warning' : 'bg-danger'))
                            .text(status);
                            
                        // Show success message
                        const alert = $('<div class="alert alert-success alert-dismissible fade show" role="alert">')
                            .text('Attendance updated successfully!')
                            .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
                        
                        $('.row:first').after(alert);
                        
                        // Auto dismiss alert after 3 seconds
                        setTimeout(() => {
                            alert.alert('close');
                        }, 3000);
                    }
                },
                error: function() {
                    const alert = $('<div class="alert alert-danger alert-dismissible fade show" role="alert">')
                        .text('Failed to update attendance')
                        .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
                    
                    $('.row:first').after(alert);
                }
            });
        });
    });
    </script>
<?php endif; ?>

<?php include '../../includes/footer.php'; ?> 