<?php
include '../../includes/header.php';
requireLogin();

if (getUserRole() !== 'teacher') {
    header("Location: ../../index.php");
    exit();
}

$teacher_id = $_SESSION['teacher_id'];
$current_date = date('Y-m-d');
$current_time = date('H:i:s');
$day_of_week = date('l'); // Gets current day name (Monday, Tuesday, etc.)

// Get teacher's schedules for today
$query = "SELECT s.*, 
          sub.subject_name,
          sec.section_name,
          sec.grade_level
          FROM schedules s
          JOIN subjects sub ON s.subject_id = sub.subject_id
          JOIN sections sec ON s.section_id = sec.section_id
          WHERE s.teacher_id = ? 
          AND s.day_of_week = ?
          ORDER BY s.start_time";

$stmt = $conn->prepare($query);
$stmt->bind_param("is", $teacher_id, $day_of_week);
$stmt->execute();
$schedules = $stmt->get_result();

// Get recent attendance records
$recent_query = "SELECT a.*, 
                 s.firstname, s.lastname,
                 sub.subject_name,
                 sec.section_name
                 FROM attendance a
                 JOIN schedules sch ON a.schedule_id = sch.schedule_id
                 JOIN students s ON a.student_id = s.student_id
                 JOIN subjects sub ON sch.subject_id = sub.subject_id
                 JOIN sections sec ON sch.section_id = sec.section_id
                 WHERE sch.teacher_id = ?
                 AND a.attendance_date = ?
                 ORDER BY a.created_at DESC
                 LIMIT 10";

$stmt = $conn->prepare($recent_query);
$stmt->bind_param("is", $teacher_id, $current_date);
$stmt->execute();
$recent_attendance = $stmt->get_result();
?>

<style>
    #changePasswordDropdown:hover {
        color: #000000 !important;
        background-color: #198754 !important;
    }
</style>

<div class="row mb-4">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <h2>Teacher Dashboard</h2>
        <div class="d-flex align-items-center gap-2">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                <i class="fas fa-plus"></i> Add Student
            </button>
            <a href="<?php echo BASE_URL; ?>/admin/manage_schedules.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> View Schedule
            </a>
            <a href="<?php echo BASE_URL; ?>/admin/teacher/attendance_reports.php" class="btn btn-info">
                <i class="fas fa-chart-bar"></i> View Reports
            </a>
            <div class="dropdown">
                <a class="btn btn-light" href="#" role="button" data-bs-toggle="dropdown">
                    <i class="fas fa-cog"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" style="background-color: #198754;">
                    <li>
                        <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#changePasswordModal" style="color: white !important;" id="changePasswordDropdown">
                            <i class="fas fa-key me-2"></i>Change Password
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <p class="text-muted">Today is <?php echo date('l, F j, Y'); ?></p>
    </div>
</div>

<!-- Add Student Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Student</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="addStudentForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Student ID</label>
                        <input type="text" class="form-control" name="student_id" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">First Name</label>
                        <input type="text" class="form-control" name="firstname" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Last Name</label>
                        <input type="text" class="form-control" name="lastname" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Middle Name</label>
                        <input type="text" class="form-control" name="middlename">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" required>
                        <small class="text-muted">Student will receive login credentials at this email</small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Section</label>
                        <select class="form-select" name="section_id" required>
                            <option value="">Select Section</option>
                            <?php
                            // Get sections assigned to this teacher
                            $stmt = $conn->prepare("SELECT DISTINCT s.section_id, s.section_name, s.grade_level 
                                                  FROM sections s 
                                                  JOIN teacher_sections ts ON s.section_id = ts.section_id 
                                                  WHERE ts.teacher_id = ? 
                                                  ORDER BY s.grade_level, s.section_name");
                            $stmt->bind_param("i", $_SESSION['teacher_id']);
                            $stmt->execute();
                            $sections = $stmt->get_result();
                            
                            while ($section = $sections->fetch_assoc()): ?>
                                <option value="<?php echo $section['section_id']; ?>">
                                    Grade <?php echo $section['grade_level']; ?> - <?php echo $section['section_name']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Student</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="row mb-4">
    <!-- Today's Schedule -->
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Today's Schedule</h5>
            </div>
            <div class="card-body">
                <?php if ($schedules->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Time</th>
                                    <th>Subject</th>
                                    <th>Section</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($schedule = $schedules->fetch_assoc()):
                                    $start_time = strtotime($schedule['start_time']);
                                    $end_time = strtotime($schedule['end_time']);
                                    $current = strtotime($current_time);
                                    $is_current = ($current >= $start_time && $current <= $end_time);
                                ?>
                                    <tr <?php echo $is_current ? 'class="table-active"' : ''; ?>>
                                        <td><?php echo date('h:i A', $start_time) . ' - ' . date('h:i A', $end_time); ?></td>
                                        <td><?php echo $schedule['subject_name']; ?></td>
                                        <td>Grade <?php echo $schedule['grade_level'] . ' - ' . $schedule['section_name']; ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $schedule['status'] === 'Open' ? 'success' : 'secondary'; ?>">
                                                <?php echo $schedule['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo BASE_URL; ?>/admin/teacher/view_section.php?section_id=<?php echo $schedule['section_id']; ?>" 
                                               class="btn btn-sm btn-primary">
                                                View Section
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No classes scheduled for today.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent Attendance -->
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Recent Attendance</h5>
            </div>
            <div class="card-body" style="height: 300px; overflow-y: auto;">
                <?php if ($recent_attendance->num_rows > 0): ?>
                    <div class="list-group">
                        <?php while ($record = $recent_attendance->fetch_assoc()): ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between">
                                    <h6 class="mb-1"><?php echo $record['lastname'] . ', ' . $record['firstname']; ?></h6>
                                    <small class="text-muted"><?php echo date('h:i A', strtotime($record['created_at'])); ?></small>
                                </div>
                                <p class="mb-1">
                                    <?php echo $record['subject_name'] . ' - ' . $record['section_name']; ?>
                                </p>
                                <small style="font-weight: bold;" class="text-<?php echo $record['status'] === 'Present' ? 'success' : 
                                    ($record['status'] === 'Late' ? 'warning' : 'danger'); ?>">
                                    <?php echo $record['status']; ?>
                                </small>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No attendance records for today.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12" style="padding: 0 !important;">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">My Sections</h5>
                </div>
                <div class="card-body" >
                    <div class="table-responsive" style="height: 300px; overflow-y: auto;">
                        <table class="table table-hover">
                            <thead>
                                <tr style="position: sticky !important; top: 0 !important; background-color: white;">
                                    <th>Grade Level</th>
                                    <th>Section</th>
                                    <th>Total Students</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $query = "SELECT s.*, 
                                         COUNT(st.student_id) as student_count 
                                         FROM sections s 
                                         LEFT JOIN students st ON s.section_id = st.section_id 
                                         JOIN teacher_sections ts ON s.section_id = ts.section_id 
                                         WHERE ts.teacher_id = ? 
                                         GROUP BY s.section_id 
                                         ORDER BY s.grade_level, s.section_name";
                                
                                $stmt = $conn->prepare($query);
                                $stmt->bind_param("i", $_SESSION['teacher_id']);
                                $stmt->execute();
                                $sections = $stmt->get_result();
                                
                                while ($section = $sections->fetch_assoc()):
                                ?>
                                <tr>
                                    <td>Grade <?php echo $section['grade_level']; ?></td>
                                    <td><?php echo $section['section_name']; ?></td>
                                    <td><?php echo $section['student_count']; ?></td>
                                    <td>
                                        <a href="view_section.php?section_id=<?php echo $section['section_id']; ?>" 
                                           class="btn btn-primary btn-sm">
                                            View Attendance
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add this where you want the calendar to appear -->
<div class="row mb-4 mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Calendar & Notes</h5>
            </div>
            <div class="card-body">
                <div id="calendar"></div>
            </div>
        </div>
    </div>
</div>

<!-- Add Note Modal -->
<div class="modal fade" id="addNoteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Note</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="addNoteForm">
                <div class="modal-body">
                    <input type="hidden" id="noteDate" name="note_date">
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input type="text" class="form-control" name="note_title" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Content</label>
                        <textarea class="form-control" name="note_content" rows="4" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Note</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View/Edit Note Modal -->
<div class="modal fade" id="viewNoteModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Note Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="editNoteId">
                <div class="mb-3">
                    <label class="form-label">Title</label>
                    <input type="text" class="form-control" id="viewNoteTitle">
                </div>
                <div class="mb-3">
                    <label class="form-label">Content</label>
                    <textarea class="form-control" id="viewNoteContent" rows="4"></textarea>
                </div>
                <div class="text-muted small" id="noteTimestamp"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger me-auto" id="deleteNoteBtn">Delete</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="updateNoteBtn">Update</button>
            </div>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>

<!-- Password Change Modal -->
<div class="modal fade" id="changePasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Change Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="changePasswordForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Current Password</label>
                        <input type="password" class="form-control" name="current_password" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" class="form-control" name="new_password" minlength="8" required>
                        <div class="form-text">Password must be at least 8 characters long</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" class="form-control" name="confirm_password" minlength="8" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Change Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Toast Container -->
<div class="toast-container">
    <div class="toast success" style="display: none;">
        <div>
            <span class="me-2">✅</span>
            <span class="toast-message"></span>
        </div>
    </div>
    <div class="toast warning" style="display: none;">
        <div>
            <span class="me-2">⚠️</span>
            <span class="toast-message"></span>
        </div>
    </div>
    <div class="toast danger" style="display: none;">
        <div>
            <span class="me-2">❌</span>
            <span class="toast-message"></span>
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="loading-overlay" style="display: none;">
    <div class="loading-content">
        <div class="spinner-border text-light mb-2" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <div class="text-light">Logging out...</div>
    </div>
</div>

<!-- Add these styles to your existing styles -->
<style>
.toast-container {
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 1060;
    width: 90%;
    max-width: 400px;
}

.toast {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    transition: opacity 0.3s ease-out;
    opacity: 0;
}

.toast.success {
    border-left: 4px solid #198754;
}

.toast.warning {
    border-left: 4px solid #ffc107;
}

.toast.danger {
    border-left: 4px solid #dc3545;
}

.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    z-index: 1070;
    display: flex;
    justify-content: center;
    align-items: center;
}

.loading-content {
    text-align: center;
}

.fc-event {
    cursor: pointer;
}
.fc-day-today {
    background-color: rgba(13, 110, 253, 0.1) !important;
}
.fc-header-toolbar {
    margin-bottom: 1rem !important;
}
</style>

<!-- Add this JavaScript before the closing </body> tag -->
<script>
// Modified showToast function with logout parameter
function showToast(message, type = 'success', shouldLogout = false) {
    console.log('Showing toast:', message, type);
    
    const toast = document.querySelector(`.toast.${type}`);
    if (!toast) {
        console.error('Toast element not found!');
        return;
    }
    
    // Set message
    toast.querySelector('.toast-message').textContent = message;
    
    // Show toast
    toast.style.display = 'flex';
    toast.style.opacity = '1';
    
    // For success with logout, show loading overlay and redirect
    if (type === 'success' && shouldLogout) {
        setTimeout(() => {
            toast.style.opacity = '0';
            document.getElementById('loadingOverlay').style.display = 'flex';
            setTimeout(() => {
                window.location.href = '<?php echo BASE_URL; ?>/auth/logout.php';
            }, 1500);
        }, 2000);
    } else {
        // For other types or success without logout, just hide the toast
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => {
                toast.style.display = 'none';
            }, 300);
        }, 3000);
    }
}

$(document).ready(function() {
    $('#changePasswordForm').submit(function(e) {
        e.preventDefault();
        
        const formData = $(this).serialize();
        const form = $(this);
        const submitBtn = form.find('button[type="submit"]');
        
        // Basic validation
        const newPass = form.find('input[name="new_password"]').val();
        const confirmPass = form.find('input[name="confirm_password"]').val();
        
        if (newPass !== confirmPass) {
            showToast('New passwords do not match', 'warning');
            return;
        }
        
        // Disable form while processing
        submitBtn.prop('disabled', true);
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/teacher/api/change_password.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#changePasswordModal').modal('hide');
                    form[0].reset();
                    showToast('Password changed successfully!', 'success', true);
                } else {
                    showToast(response.error || 'Failed to change password', 'danger');
                }
            },
            error: function() {
                showToast('Failed to change password', 'danger');
            },
            complete: function() {
                submitBtn.prop('disabled', false);
            }
        });
    });
});
</script>

<script>
// Add this after your existing JavaScript
$('#addStudentForm').submit(function(e) {
    e.preventDefault();
    const form = $(this);
    const submitButton = form.find('button[type="submit"]');
    
    // Disable submit button
    submitButton.prop('disabled', true);
    
    $.ajax({
        url: '<?php echo BASE_URL; ?>/admin/api/add_student.php',
        method: 'POST',
        data: form.serialize(),
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                showAlert(response.message);
                $('#addStudentModal').modal('hide');
                form[0].reset();
                // Optionally reload the page after a delay
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } else {
                showAlert(response.error, 'danger');
            }
        },
        error: function() {
            showAlert('Failed to add student. Please try again.', 'danger');
        },
        complete: function() {
            submitButton.prop('disabled', false);
        }
    });
});

// Add this function if not already present
function showAlert(message, type = 'success') {
    const alert = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">')
        .text(message)
        .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
    
    $('.row:first').after(alert);
    
    setTimeout(() => {
        alert.alert('close');
    }, 3000);
}
</script> 

<!-- Required scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js'></script>

<!-- Add this JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const calendarEl = document.getElementById('calendar');
    const calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 'auto',
        selectable: true,
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: '<?php echo BASE_URL; ?>/admin/teacher/api/get_notes.php',
        select: function(info) {
            $('#noteDate').val(info.startStr);
            $('#addNoteModal').modal('show');
        },
        eventClick: function(info) {
            const event = info.event;
            $('#editNoteId').val(event.id);
            $('#viewNoteTitle').val(event.title);
            $('#viewNoteContent').val(event.extendedProps.content);
            $('#noteTimestamp').text('Last updated: ' + event.extendedProps.updated_at);
            $('#viewNoteModal').modal('show');
        }
    });
    calendar.render();

    // Add Note Form Handler
    $('#addNoteForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/teacher/api/add_note.php',
            method: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    $('#addNoteModal').modal('hide');
                    calendar.refetchEvents();
                    showToast('Note added successfully!', 'success', false);
                    window.location.reload();
                } else {
                    showToast(response.error || 'Failed to add note', 'danger');
                }
            },
            error: function() {
                showToast('Failed to add note', 'danger');
            }
        });
    });

    // Update Note Handler
    $('#updateNoteBtn').click(function() {
        const noteId = $('#editNoteId').val();
        const title = $('#viewNoteTitle').val();
        const content = $('#viewNoteContent').val();

        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/teacher/api/update_note.php',
            method: 'POST',
            data: {
                note_id: noteId,
                note_title: title,
                note_content: content
            },
            success: function(response) {
                if (response.success) {
                    $('#viewNoteModal').modal('hide');
                    calendar.refetchEvents();
                    showToast('Note updated successfully!', 'success', false);
                    window.location.reload();
                } else {
                    showToast(response.error || 'Failed to update note', 'danger');
                }
            },
            error: function() {
                showToast('Failed to update note', 'danger');
            }
        });
    });

    // Delete Note Handler
    $('#deleteNoteBtn').click(function() {
        if (confirm('Are you sure you want to delete this note?')) {
            const noteId = $('#editNoteId').val();

            $.ajax({
                url: '<?php echo BASE_URL; ?>/admin/teacher/api/delete_note.php',
                method: 'POST',
                data: { note_id: noteId },
                success: function(response) {
                    if (response.success) {
                        $('#viewNoteModal').modal('hide');
                        calendar.refetchEvents();
                        showToast('Note deleted successfully!', 'success', false);
                        window.location.reload();
                    } else {
                        showToast(response.error || 'Failed to delete note', 'danger');
                    }
                },
                error: function() {
                    showToast('Failed to delete note', 'danger');
                }
            });
        }
    });
});
</script>