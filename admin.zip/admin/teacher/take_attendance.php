<?php
require_once '../../includes/config.php';
require_once '../../config/database.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';

if (!isLoggedIn() || getUserRole() !== 'teacher') {
    exit('Unauthorized');
}

$section_id = isset($_GET['section_id']) ? (int)$_GET['section_id'] : 0;
$teacher_id = $_SESSION['teacher_id'];
$current_date = date('Y-m-d');
$day_of_week = date('l');

// Get today's schedules for this section
$schedule_query = "SELECT s.*, sub.subject_name 
                  FROM schedules s
                  JOIN subjects sub ON s.subject_id = sub.subject_id
                  WHERE s.section_id = ? 
                  AND s.teacher_id = ?
                  AND s.day_of_week = ?
                  ORDER BY s.start_time";

$stmt = $conn->prepare($schedule_query);
$stmt->bind_param("iis", $section_id, $teacher_id, $day_of_week);
$stmt->execute();
$schedules = $stmt->get_result();
?>

<div class="modal-header">
    <h5 class="modal-title">Take Attendance - <?php echo date('l, F j, Y'); ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body">
    <?php if ($schedules->num_rows === 0): ?>
        <div class="alert alert-info">No schedules found for today.</div>
    <?php else: ?>
        <!-- Schedule Selection -->
        <div class="mb-3">
            <label class="form-label">Select Schedule:</label>
            <select class="form-select" id="scheduleSelect">
                <?php while ($schedule = $schedules->fetch_assoc()): ?>
                    <option value="<?php echo $schedule['schedule_id']; ?>">
                        <?php 
                        echo $schedule['subject_name'] . ' (' . 
                             date('h:i A', strtotime($schedule['start_time'])) . ' - ' .
                             date('h:i A', strtotime($schedule['end_time'])) . ')';
                        ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Student List -->
        <div id="studentList">
            <!-- Will be populated via AJAX -->
        </div>
    <?php endif; ?>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button type="button" class="btn btn-primary" id="saveAttendance">Save Attendance</button>
</div>

<script>
$(document).ready(function() {
    // Function to show alerts
    function showAlert(message, type = 'success') {
        const alert = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">')
            .text(message)
            .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
        
        $('.modal-body').prepend(alert);
        
        // Auto dismiss after 3 seconds
        setTimeout(() => {
            alert.alert('close');
        }, 3000);
    }

    const loadStudentList = () => {
        const scheduleId = $('#scheduleSelect').val();
        $.get('<?php echo BASE_URL; ?>/teacher/get_attendance_list.php', {
            schedule_id: scheduleId,
            section_id: <?php echo $section_id; ?>,
            date: '<?php echo $current_date; ?>'
        }, function(data) {
            $('#studentList').html(data);
        });
    };

    // Load initial student list
    loadStudentList();

    // Reload when schedule changes
    $('#scheduleSelect').change(loadStudentList);

    // Save attendance
    $('#saveAttendance').click(function() {
        const scheduleId = $('#scheduleSelect').val();
        const attendance = [];
        
        $('.student-attendance').each(function() {
            attendance.push({
                student_id: $(this).data('student'),
                status: $(this).val()
            });
        });

        $.post('<?php echo BASE_URL; ?>/teacher/save_attendance.php', {
            schedule_id: scheduleId,
            date: '<?php echo $current_date; ?>',
            attendance: JSON.stringify(attendance)
        }, function(response) {
            if (response.success) {
                showAlert('Attendance saved successfully', 'success');
                $('#attendanceModal').modal('hide');
                // Optionally reload the page
                //setTimeout(() => location.reload(), 1500);
            } else {
                showAlert('Failed to save attendance', 'danger');
            }
        });
    });
});
</script> 