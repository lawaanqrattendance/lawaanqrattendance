<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth.php';

if (!isLoggedIn() || getUserRole() !== 'teacher') {
    exit('Unauthorized access');
}

$teacher_id = $_SESSION['teacher_id'];
$section_id = isset($_GET['section_id']) ? intval($_GET['section_id']) : 0;
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d', strtotime('-30 days'));
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d');
$status = isset($_GET['status']) ? $_GET['status'] : '';

// Base query
$query = "SELECT 
            a.attendance_date,
            a.status,
            a.created_at,
            s.student_id,
            s.firstname,
            s.lastname,
            sec.section_name,
            sec.grade_level,
            sub.subject_name,
            CONCAT(TIME_FORMAT(sch.start_time, '%h:%i %p'), ' - ', 
                   TIME_FORMAT(sch.end_time, '%h:%i %p')) as schedule_time,
            sch.day_of_week
          FROM attendance a
          JOIN students s ON a.student_id = s.student_id
          JOIN schedules sch ON a.schedule_id = sch.schedule_id
          JOIN sections sec ON s.section_id = sec.section_id
          JOIN subjects sub ON sch.subject_id = sub.subject_id
          WHERE sch.teacher_id = ? 
          AND a.attendance_date BETWEEN ? AND ?";

$params = [$teacher_id, $start_date, $end_date];
$types = "iss";

if ($section_id) {
    $query .= " AND s.section_id = ?";
    $params[] = $section_id;
    $types .= "i";
}

if ($status) {
    $query .= " AND a.status = ?";
    $params[] = $status;
    $types .= "s";
}

$query .= " ORDER BY a.attendance_date DESC, s.lastname, s.firstname";

$stmt = $conn->prepare($query);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo '<div class="alert alert-info">No attendance records found for the selected criteria.</div>';
    exit;
}

// Calculate statistics
$total_records = $result->num_rows;
$status_counts = [
    'Present' => 0,
    'Late' => 0,
    'Absent' => 0
];

$data = [];
while ($row = $result->fetch_assoc()) {
    $status_counts[$row['status']]++;
    $data[] = $row;
}

// Output the summary first
echo '<div id="summary">';
echo '<div class="card mb-4">
    <div class="card-body">
        <h5 class="card-title">Summary</h5>
        <div class="row">
            <div class="col-md-3">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h6>Present</h6>
                        <h3>' . $status_counts['Present'] . '</h3>
                        <small>' . round(($status_counts['Present'] / $total_records) * 100, 1) . '%</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h6>Late</h6>
                        <h3>' . $status_counts['Late'] . '</h3>
                        <small>' . round(($status_counts['Late'] / $total_records) * 100, 1) . '%</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <h6>Absent</h6>
                        <h3>' . $status_counts['Absent'] . '</h3>
                        <small>' . round(($status_counts['Absent'] / $total_records) * 100, 1) . '%</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h6>Total Records</h6>
                        <h3>' . $total_records . '</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>';
echo '</div>';

// Output the list with its own div
echo '<div id="list">';
// Detailed Report Table
echo '<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>Date</th>
                <th>Student</th>
                <th>Section</th>
                <th>Subject</th>
                <th>Schedule</th>
                <th>Status</th>
                <th>Time Recorded</th>
            </tr>
        </thead>
        <tbody>';
foreach ($data as $row):
    echo '<tr>';
    echo '<td>' . date('M d, Y', strtotime($row['attendance_date'])) . '</td>';
    echo '<td>' . htmlspecialchars($row['lastname'] . ', ' . $row['firstname']) . '</td>';
    echo '<td>Grade ' . $row['grade_level'] . ' - ' . $row['section_name'] . '</td>';
    echo '<td>' . htmlspecialchars($row['subject_name']) . '</td>';
    echo '<td>' . $row['day_of_week'] . ' ' . $row['schedule_time'] . '</td>';
    echo '<td>';
    echo '<span class="badge bg-' . ($row['status'] === 'Present' ? 'success' : ($row['status'] === 'Late' ? 'warning' : 'danger')) . '">';
    echo $row['status'];
    echo '</span>';
    echo '</td>';
    echo '<td>' . date('h:i A', strtotime($row['created_at'])) . '</td>';
    echo '</tr>';
endforeach;
echo '</tbody>';
echo '</table>';
echo '</div>';
echo '</div>'; 