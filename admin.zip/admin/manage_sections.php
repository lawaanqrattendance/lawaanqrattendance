<?php
include '../includes/header.php';
requireLogin();

if (getUserRole() !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// Handle form submission with resubmission prevention
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $section_name = cleanInput($_POST['section_name']);
                $grade_level = cleanInput($_POST['grade_level']);
                
                $stmt = $conn->prepare("INSERT INTO sections (section_name, grade_level) VALUES (?, ?)");
                $stmt->bind_param("si", $section_name, $grade_level);
                
                if ($stmt->execute()) {
                    $_SESSION['success'] = "Section added successfully!";
                    header("Location: " . $_SERVER['PHP_SELF']);
                    exit();
                } else {
                    $_SESSION['error'] = "Error adding section.";
                }
                break;
        }
    }
}

// Display session messages
if (isset($_SESSION['success'])) {
    echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
    echo $_SESSION['success'];
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
    unset($_SESSION['success']);
}

if (isset($_SESSION['error'])) {
    echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
    echo $_SESSION['error'];
    echo '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
    echo '</div>';
    unset($_SESSION['error']);
}

// Get all sections
$query = "SELECT * FROM sections ORDER BY grade_level, section_name";
$sections = $conn->query($query);
?>

<div class="row mb-4">
    <div class="col-md-12 d-flex justify-content-between align-items-center">
        <h2>Manage Sections</h2>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSectionModal">
            Add New Section
        </button>
    </div>
</div>

<!-- Sections Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Section Name</th>
                        <th>Grade Level</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($section = $sections->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $section['section_id']; ?></td>
                            <td><?php echo $section['section_name']; ?></td>
                            <td><?php echo $section['grade_level']; ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary edit-section" 
                                        data-id="<?php echo $section['section_id']; ?>"
                                        data-name="<?php echo $section['section_name']; ?>"
                                        data-grade="<?php echo $section['grade_level']; ?>">
                                    Edit
                                </button>
                                <button class="btn btn-sm btn-danger delete-section" 
                                        data-id="<?php echo $section['section_id']; ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Section Modal -->
<div class="modal fade" id="addSectionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add New Section</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label class="form-label">Section Name</label>
                        <input type="text" class="form-control" name="section_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Grade Level</label>
                        <input type="number" class="form-control" name="grade_level" min="7" max="12" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add Section</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Edit Modal -->
<div class="modal fade" id="editSectionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Section</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="editSectionForm">
                <div class="modal-body">
                    <input type="hidden" name="section_id" id="edit_section_id">
                    
                    <div class="mb-3">
                        <label class="form-label">Section Name</label>
                        <input type="text" class="form-control" name="section_name" id="edit_section_name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Grade Level</label>
                        <input type="number" class="form-control" name="grade_level" id="edit_grade_level" required min="7" max="12">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add JavaScript -->
<script>
$(document).ready(function() {
    function showAlert(message, type = 'success') {
        const alert = $('<div class="alert alert-' + type + ' alert-dismissible fade show" role="alert">')
            .text(message)
            .append('<button type="button" class="btn-close" data-bs-dismiss="alert"></button>');
        
        $('.row:first').after(alert);
        
        setTimeout(() => {
            alert.alert('close');
        }, 3000);
    }

    // Edit Section
    $('.edit-section').click(function() {
        const button = $(this);
        const id = button.data('id');
        const name = button.data('name');
        const grade = button.data('grade');
        
        $('#edit_section_id').val(id);
        $('#edit_section_name').val(name);
        $('#edit_grade_level').val(grade);
        
        $('#editSectionModal').modal('show');
    });
    
    $('#editSectionForm').submit(function(e) {
        e.preventDefault();
        const formData = $(this).serialize();
        
        $.ajax({
            url: '<?php echo BASE_URL; ?>/admin/api/update_section.php',
            method: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                $('#editSectionModal').modal('hide');
                if (response.success) {
                    showAlert('Section updated successfully!');
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                } else {
                    showAlert(response.error || 'Failed to update section', 'danger');
                }
            },
            error: function(xhr) {
                $('#editSectionModal').modal('hide');
                const errorMsg = xhr.responseJSON?.error || 'Failed to update section';
                showAlert(errorMsg, 'danger');
            }
        });
    });
    
    // Delete Section
    $('.delete-section').click(function() {
        if (confirm('Are you sure you want to delete this section? This will also delete all related records.')) {
            const button = $(this);
            const id = button.data('id');
            
            button.prop('disabled', true);
            
            $.ajax({
                url: '<?php echo BASE_URL; ?>/admin/api/delete_section.php',
                method: 'POST',
                data: { section_id: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        showAlert('Section deleted successfully!');
                        button.closest('tr').fadeOut(400, function() {
                            $(this).remove();
                        });
                    } else {
                        showAlert(response.error || 'Failed to delete section', 'danger');
                        button.prop('disabled', false);
                    }
                },
                error: function(xhr) {
                    const errorMsg = xhr.responseJSON?.error || 'Failed to delete section';
                    showAlert(errorMsg, 'danger');
                    button.prop('disabled', false);
                }
            });
        }
    });
});
</script>

<?php include '../includes/footer.php'; ?>