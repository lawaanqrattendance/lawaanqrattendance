<?php
include '../includes/header.php';
requireLogin();

if (getUserRole() !== 'admin') {
    header("Location: " . BASE_URL . "/index.php");
    exit();
}

// Add these at the top of the file with other includes
require '../vendor/autoload.php'; // For PHPMailer
require_once '../config/email_config.php'; // For email settings

// At the beginning of the POST handling section
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'reset_password':
                $user_id = cleanInput($_POST['user_id']);
                $username = cleanInput($_POST['username']);
                // Reset password to username
                $password = password_hash($username, PASSWORD_DEFAULT);
                
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $stmt->bind_param("si", $password, $user_id);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Password reset successfully for user: " . $username;
                } else {
                    $_SESSION['error_message'] = "Failed to reset password";
                }
                break;
                
            case 'delete':
                $user_id = cleanInput($_POST['user_id']);
                $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ? AND role != 'admin'");
                $stmt->bind_param("i", $user_id);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "User deleted successfully";
                } else {
                    $_SESSION['error_message'] = "Failed to delete user";
                }
                break;

            case 'resend_verification':
                $user_id = cleanInput($_POST['user_id']);
                $email = cleanInput($_POST['email']);
                
                // Generate new verification code
                $verification_code = sprintf("%06d", mt_rand(1, 999999));
                $code_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                $stmt = $conn->prepare("UPDATE users SET verification_code = ?, code_expiry = ?, email_verified = 0 WHERE user_id = ?");
                $stmt->bind_param("ssi", $verification_code, $code_expiry, $user_id);
                
                if ($stmt->execute()) {
                    // Send verification email using PHPMailer
                    $mail = new PHPMailer\PHPMailer\PHPMailer(true);

                    try {
                        $mail->isSMTP();
                        $mail->Host = SMTP_HOST;
                        $mail->SMTPAuth = true;
                        $mail->Username = SMTP_USERNAME;
                        $mail->Password = SMTP_PASSWORD;
                        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                        $mail->Port = 587;

                        $mail->setFrom(SMTP_USERNAME, SMTP_FROM_NAME);
                        $mail->addAddress($email);

                        $mail->isHTML(true);
                        $mail->Subject = 'New Verification Code - Attendance System';
                        $mail->Body = "
                            <html>
                            <body style='font-family: Arial, sans-serif;'>
                                <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
                                    <h2>New Verification Code</h2>
                                    <p>Your new verification code is: <strong>{$verification_code}</strong></p>
                                    <p>This code will expire in 1 hour.</p>
                                </div>
                            </body>
                            </html>";

                        $mail->send();
                        $_SESSION['success_message'] = "Verification code resent successfully";
                    } catch (Exception $e) {
                        error_log("Email Error: {$mail->ErrorInfo}");
                        $_SESSION['error_message'] = "Failed to send verification email";
                    }
                } else {
                    $_SESSION['error_message'] = "Failed to generate new verification code";
                }
                
                // Redirect after processing
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
        }
        
        // Redirect after any action
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

// At the top of the page, after session start
if (isset($_SESSION['success_message'])) {
    $success = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}

if (isset($_SESSION['error_message'])) {
    $error = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// Get all users with their details
$query = "SELECT u.*, 
          CASE 
            WHEN u.role = 'student' THEN s.firstname
            WHEN u.role = 'teacher' THEN t.firstname
            ELSE 'Admin'
          END as firstname,
          CASE 
            WHEN u.role = 'student' THEN s.lastname
            WHEN u.role = 'teacher' THEN t.lastname
            ELSE 'Administrator'
          END as lastname,
          CASE 
            WHEN u.role = 'student' THEN s.email
            ELSE NULL
          END as email,
          u.email_verified,
          u.code_expiry
          FROM users u
          LEFT JOIN students s ON u.reference_id = s.student_id AND u.role = 'student'
          LEFT JOIN teachers t ON u.reference_id = t.teacher_id AND u.role = 'teacher'
          ORDER BY u.role, lastname, firstname";

$users = $conn->query($query);
?>

<div class="row mb-4">
    <div class="col-md-12">
        <h2>Manage User Accounts</h2>
    </div>
</div>

<?php if (isset($success)): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (isset($error)): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo $error; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Users Table -->
<div class="card" style="padding: 0;">
    <div class="card-body">
        <div class="table-responsive" style="height: 650px; overflow-y: auto;">
            <table class="table table-striped">
                <thead style="position: sticky; top: 0; background: #f8f9fa;">
                    <tr>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Verification Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($user = $users->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $user['username']; ?></td>
                            <td><?php echo $user['lastname'] . ', ' . $user['firstname']; ?></td>
                            <td>
                                <span class="badge bg-<?php 
                                    echo $user['role'] === 'admin' ? 'danger' : 
                                        ($user['role'] === 'teacher' ? 'success' : 'primary'); 
                                ?>">
                                    <?php echo ucfirst($user['role']); ?>
                                </span>
                            </td>
                            <td><?php echo $user['email'] ?? 'N/A'; ?></td>
                            <td>
                                <?php if ($user['role'] === 'student'): ?>
                                    <?php if ($user['email_verified']): ?>
                                        <span class="badge bg-success">Verified</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Pending</span>
                                        <?php if ($user['code_expiry'] && strtotime($user['code_expiry']) < time()): ?>
                                            <span class="badge bg-danger">Expired</span>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge bg-secondary">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($user['role'] !== 'admin'): ?>
                                    <button type="button" 
                                            class="btn btn-warning btn-sm" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#resetPasswordModal"
                                            data-user-id="<?php echo $user['user_id']; ?>"
                                            data-username="<?php echo $user['username']; ?>">
                                        Reset Password
                                    </button>
                                    <?php if ($user['role'] === 'student' && !$user['email_verified']): ?>
                                        <button type="button" 
                                                class="btn btn-info btn-sm"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#resendVerificationModal"
                                                data-user-id="<?php echo $user['user_id']; ?>"
                                                data-email="<?php echo $user['email']; ?>"
                                                data-username="<?php echo $user['username']; ?>">
                                            Resend Code
                                        </button>
                                    <?php endif; ?>
                                    <button type="button" 
                                            class="btn btn-danger btn-sm" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#deleteUserModal"
                                            data-user-id="<?php echo $user['user_id']; ?>"
                                            data-username="<?php echo $user['username']; ?>"
                                            title="Delete User">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Reset Password Modal -->
<div class="modal fade" id="resetPasswordModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Reset Password</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="user_id" id="resetUserId">
                    <input type="hidden" name="username" id="resetUsername">
                    <p>Are you sure you want to reset the password for <strong id="resetUserDisplay"></strong>?</p>
                    <p class="text-muted">The password will be reset to their username.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete User Modal -->
<div class="modal fade" id="deleteUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Delete User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="user_id" id="deleteUserId">
                    <p>Are you sure you want to delete user <strong id="deleteUserDisplay"></strong>?</p>
                    <p class="text-danger">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete User</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Resend Verification Modal -->
<div class="modal fade" id="resendVerificationModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Resend Verification Code</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="resend_verification">
                    <input type="hidden" name="user_id" id="verifyUserId">
                    <input type="hidden" name="email" id="verifyEmail">
                    <p>Resend verification code to <strong id="verifyUserDisplay"></strong>?</p>
                    <p class="text-muted">A new verification code will be sent to their email.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Resend Code</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Reset Password Modal
    $('#resetPasswordModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget);
        const userId = button.data('user-id');
        const username = button.data('username');
        
        $('#resetUserId').val(userId);
        $('#resetUsername').val(username);
        $('#resetUserDisplay').text(username);
    });
    
    // Delete User Modal
    $('#deleteUserModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget);
        const userId = button.data('user-id');
        const username = button.data('username');
        
        $('#deleteUserId').val(userId);
        $('#deleteUserDisplay').text(username);
    });

    // Resend Verification Modal
    $('#resendVerificationModal').on('show.bs.modal', function (event) {
        const button = $(event.relatedTarget);
        const userId = button.data('user-id');
        const email = button.data('email');
        const username = button.data('username');
        
        $('#verifyUserId').val(userId);
        $('#verifyEmail').val(email);
        $('#verifyUserDisplay').text(username);
    });
});
</script>

<?php include '../includes/footer.php'; ?> 